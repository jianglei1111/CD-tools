import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, "..");
const codexHome = process.env.CODEX_HOME || path.join(process.env.HOME || os.homedir(), ".codex");
const configPath = path.join(codexHome, "config.toml");
const skillPath = path.join(codexHome, "skills", "weixin-codex", "SKILL.md");
const probeCodex = process.argv.includes("--probe-codex");
const REQUIRED_CODEX_BASE_URL = "https://www.chedankj.com";

let failed = false;
let warned = false;

printHeader();
checkNode();
checkCommand("node", ["-v"], "node 命令", {
  failureHint: "Node.js 命令不可用；安装负责人需要先安装或修复 Node.js，再重新检查",
});
checkCommand("npm", ["--version"], "npm");
const codexVersion = checkCommand("codex", ["--version"], "Codex CLI");
checkCodexConfig();
checkSkill();
checkDependencies();
checkOptionalConverters();
if (probeCodex && codexVersion.ok) {
  probeCodexExecution();
}

if (failed) {
  process.exitCode = 1;
} else if (warned) {
  console.log("\n结论：环境可继续安装/启动，但有警告项需要注意。");
} else {
  console.log("\n结论：环境检查通过。");
}

function printHeader() {
  console.log("Weixin Codex Bridge 环境检查");
  console.log(`目录：${repoRoot}`);
  console.log(`CODEX_HOME：${codexHome}`);
  console.log("说明：这里只检查当前机器上的本地 Codex 环境，不会带出打包者的配置。");
  console.log("安装要求：Node.js、npm、Codex CLI 和 Codex 配置都需要可用；缺失或不可用时先安装/修复，再继续。");
  console.log("");
}

function checkNode() {
  const version = process.versions.node;
  if (compareVersions(version, "18.17.0") < 0) {
    fail(`Node.js ${version}`, "需要 Node.js >= 18.17");
    return;
  }
  ok(`Node.js ${version}`);
}

function checkCommand(command, args, label, options = {}) {
  const result = spawnSync(command, args, {
    cwd: repoRoot,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
    windowsHide: true,
  });
  if (result.error || result.status !== 0) {
    fail(label, formatCommandFailure(command, result, options.failureHint));
    return { ok: false };
  }
  ok(`${label} ${firstLine(result.stdout)}`);
  return { ok: true, stdout: result.stdout };
}

function formatCommandFailure(command, result, failureHint = "") {
  const pieces = [];
  const detail = [
    result.error?.code,
    result.error?.message,
    firstLine(result.stderr),
    firstLine(result.stdout),
  ].filter(Boolean).join(" ");

  if (/EACCES|access is denied/i.test(detail)) {
    pieces.push(`${command} 运行失败：当前用户无权执行该命令（Access is denied）`);
  } else {
    pieces.push(`${command} 不可用`);
  }

  if (failureHint) {
    pieces.push(failureHint);
  }
  return pieces.join("。");
}

function checkCodexConfig() {
  if (!fs.existsSync(configPath)) {
    fail("Codex 配置", `未找到 ${configPath}。请先去官网查看安装教程。`);
    return;
  }

  ok(`Codex 配置 ${configPath}`);
  const text = fs.readFileSync(configPath, "utf8");
  const baseUrl = matchTomlString(text, "base_url");
  if (!baseUrl) {
    fail("Codex provider", `未检测到 base_url，要求为 ${REQUIRED_CODEX_BASE_URL}。请先去官网查看安装教程。`);
    return;
  }
  if (baseUrl !== REQUIRED_CODEX_BASE_URL) {
    fail("Codex provider", `当前 base_url=${baseUrl}，要求为 ${REQUIRED_CODEX_BASE_URL}。请先去官网查看安装教程。`);
    return;
  }
  ok(`Codex provider ${baseUrl}`);
}

function checkSkill() {
  if (fs.existsSync(skillPath)) {
    ok(`微信 skill 已安装 ${skillPath}`);
    return;
  }
  warn("微信 skill", "未安装；运行 node scripts/bootstrap.js 或 npm run install-skill 即可安装");
}

function checkDependencies() {
  ok("npm 依赖检查通过");
}

function checkOptionalConverters() {
  const result = spawnSync("/bin/bash", ["-lc", "command -v libreoffice || command -v soffice || command -v lowriter || command -v pandoc || true"], {
    cwd: repoRoot,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
    windowsHide: true,
  });
  const tool = firstLine(result.stdout);
  if (tool) {
    ok(`文档转换工具 ${tool}`);
    return;
  }
  warn("文档转换工具", "未检测到 libreoffice/soffice/pandoc；图片转 PDF 没问题，但 docx/xlsx/pptx 转 PDF 需要额外安装");
}

function probeCodexExecution() {
  const result = spawnSync("codex", [
    "exec",
    "--skip-git-repo-check",
    "--sandbox",
    "read-only",
    "-c",
    'approval_policy="never"',
    "只回复 OK",
  ], {
    cwd: repoRoot,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
    timeout: 120000,
    windowsHide: true,
  });

  if (result.error || result.status !== 0) {
    fail("Codex 连通性", firstLine(result.stderr) || firstLine(result.stdout) || "Codex 执行探针失败");
    return;
  }
  ok("Codex 连通性 OK");
}

function compareVersions(left, right) {
  const leftParts = left.split(".").map((part) => Number.parseInt(part, 10) || 0);
  const rightParts = right.split(".").map((part) => Number.parseInt(part, 10) || 0);
  const length = Math.max(leftParts.length, rightParts.length);
  for (let index = 0; index < length; index += 1) {
    const diff = (leftParts[index] || 0) - (rightParts[index] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

function matchTomlString(text, key) {
  const match = text.match(new RegExp(`^\\s*${key}\\s*=\\s*"([^"]+)"`, "m"));
  return match?.[1] || "";
}

function firstLine(text) {
  return String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .find(Boolean) || "";
}

function ok(message) {
  console.log(`[OK] ${message}`);
}

function warn(label, message) {
  warned = true;
  console.log(`[WARN] ${label}: ${message}`);
}

function fail(label, message) {
  failed = true;
  console.log(`[FAIL] ${label}: ${message}`);
}
