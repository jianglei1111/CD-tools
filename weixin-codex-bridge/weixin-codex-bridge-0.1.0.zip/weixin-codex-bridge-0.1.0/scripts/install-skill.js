import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import zlib from "node:zlib";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, "..");
const source = path.join(repoRoot, "skills", "weixin-codex");
const codexHome = process.env.CODEX_HOME || path.join(process.env.HOME || "", ".codex");
const skillsRoot = path.join(codexHome, "skills");
const target = path.join(skillsRoot, "weixin-codex");
const optionalArchiveCandidates = [
  path.join(repoRoot, "chedan-image2-skill.zip"),
  path.join(path.dirname(repoRoot), "chedan-image2-skill.zip"),
];

fs.mkdirSync(skillsRoot, { recursive: true });
fs.rmSync(target, { recursive: true, force: true });
fs.cpSync(source, target, { recursive: true });

console.log(`installed skill: ${target}`);

installOptionalArchive();

function installOptionalArchive() {
  const archivePath = optionalArchiveCandidates.find((candidate) => fs.existsSync(candidate));
  if (!archivePath) {
    console.log("optional skill archive not found: chedan-image2-skill.zip");
    return;
  }

  const zipBuffer = fs.readFileSync(archivePath);
  const entries = listZipEntries(zipBuffer);
  const skillRoot = detectSkillRoot(entries);
  const skillDir = path.join(skillsRoot, skillRoot);
  const skillFile = path.join(skillDir, "SKILL.md");

  if (fs.existsSync(skillFile)) {
    console.log(`optional skill already installed: ${skillDir}`);
    return;
  }
  if (fs.existsSync(skillDir)) {
    throw new Error(`optional skill target exists without SKILL.md: ${skillDir}`);
  }

  extractZip(zipBuffer, entries, skillsRoot);
  console.log(`installed optional skill: ${skillDir}`);
}

function listZipEntries(buffer) {
  const eocdOffset = findEndOfCentralDirectory(buffer);
  const centralDirectorySize = buffer.readUInt32LE(eocdOffset + 12);
  const centralDirectoryOffset = buffer.readUInt32LE(eocdOffset + 16);
  const entries = [];

  for (let offset = centralDirectoryOffset; offset < centralDirectoryOffset + centralDirectorySize;) {
    if (buffer.readUInt32LE(offset) !== 0x02014b50) {
      throw new Error(`invalid zip central directory header at ${offset}`);
    }

    const compressedSize = buffer.readUInt32LE(offset + 20);
    const fileNameLength = buffer.readUInt16LE(offset + 28);
    const extraLength = buffer.readUInt16LE(offset + 30);
    const commentLength = buffer.readUInt16LE(offset + 32);

    entries.push({
      compressedSize,
      localHeaderOffset: buffer.readUInt32LE(offset + 42),
      method: buffer.readUInt16LE(offset + 10),
      name: normalizeZipPath(buffer.slice(offset + 46, offset + 46 + fileNameLength).toString("utf8")),
    });

    offset += 46 + fileNameLength + extraLength + commentLength;
  }

  return entries;
}

function detectSkillRoot(entries) {
  const skillEntry = entries.find((entry) => entry.name.endsWith("/SKILL.md"));
  if (!skillEntry) {
    throw new Error("optional skill archive does not contain SKILL.md");
  }
  const [root] = skillEntry.name.split("/");
  if (!root) {
    throw new Error("optional skill archive has an invalid root directory");
  }
  return root;
}

function extractZip(buffer, entries, destinationRoot) {
  for (const entry of entries) {
    if (!entry.name || entry.name.endsWith("/")) continue;

    const destinationPath = resolveZipDestination(destinationRoot, entry.name);
    fs.mkdirSync(path.dirname(destinationPath), { recursive: true });
    fs.writeFileSync(destinationPath, readZipEntry(buffer, entry));
  }
}

function readZipEntry(buffer, entry) {
  const headerOffset = entry.localHeaderOffset;
  if (buffer.readUInt32LE(headerOffset) !== 0x04034b50) {
    throw new Error(`invalid zip local header at ${headerOffset}`);
  }

  const fileNameLength = buffer.readUInt16LE(headerOffset + 26);
  const extraLength = buffer.readUInt16LE(headerOffset + 28);
  const dataOffset = headerOffset + 30 + fileNameLength + extraLength;
  const compressed = buffer.slice(dataOffset, dataOffset + entry.compressedSize);

  if (entry.method === 0) return compressed;
  if (entry.method === 8) return zlib.inflateRawSync(compressed);
  throw new Error(`unsupported zip compression method: ${entry.method}`);
}

function resolveZipDestination(destinationRoot, relativePath) {
  const parts = relativePath.split("/").filter(Boolean);
  if (parts.length === 0 || parts.some((part) => part === "." || part === "..")) {
    throw new Error(`invalid zip path: ${relativePath}`);
  }

  const destinationPath = path.resolve(destinationRoot, ...parts);
  const rootPrefix = destinationRoot.endsWith(path.sep) ? destinationRoot : `${destinationRoot}${path.sep}`;
  if (destinationPath !== destinationRoot && !destinationPath.startsWith(rootPrefix)) {
    throw new Error(`zip path escapes destination: ${relativePath}`);
  }
  return destinationPath;
}

function normalizeZipPath(name) {
  return name.replace(/\\/g, "/").replace(/^\/+/, "").replace(/\/+/g, "/");
}

function findEndOfCentralDirectory(buffer) {
  for (let offset = buffer.length - 22; offset >= 0; offset -= 1) {
    if (buffer.readUInt32LE(offset) === 0x06054b50) {
      return offset;
    }
  }
  throw new Error("zip end of central directory not found");
}
