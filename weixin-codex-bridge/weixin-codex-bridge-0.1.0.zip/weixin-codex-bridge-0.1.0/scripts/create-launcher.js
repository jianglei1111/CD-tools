import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import { resolveDefaultSandbox } from "../src/runtime-defaults.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, "..");
const homeDir = process.env.HOME || process.env.USERPROFILE || os.homedir();
const platform = process.platform;

const targetDir = resolveLauncherDir(homeDir);
fs.mkdirSync(targetDir, { recursive: true });

const launcher = buildLauncher({ platform, repoRoot });
const targetPath = path.join(targetDir, launcher.fileName);

fs.writeFileSync(targetPath, launcher.content, launcher.encoding);
if (launcher.executable) {
  fs.chmodSync(targetPath, 0o755);
}

console.log(`已创建启动脚本：${targetPath}`);
console.log("双击该脚本即可启动微信-Codex 后台服务。");
console.log("电脑重启后，如需恢复服务，再次双击该脚本即可。");

function resolveLauncherDir(home) {
  const desktopCandidates = [
    path.join(home, "Desktop"),
    path.join(home, "desktop"),
    path.join(home, "桌面"),
  ];
  for (const candidate of desktopCandidates) {
    if (fs.existsSync(candidate) && fs.statSync(candidate).isDirectory()) {
      return candidate;
    }
  }
  return home;
}

function buildLauncher({ platform: currentPlatform, repoRoot: root }) {
  if (currentPlatform === "win32") {
    const sandbox = resolveDefaultSandbox("", currentPlatform);
    return {
      fileName: "Start-Weixin-Codex-Bridge.cmd",
      content: [
        "@echo off",
        `cd /d "${root}"`,
        `if "%CODEX_BRIDGE_SANDBOX%"=="" set "CODEX_BRIDGE_SANDBOX=${sandbox}"`,
        "call npm run start",
        "if errorlevel 1 (",
        "  echo.",
        "  echo Start failed.",
        "  pause",
        ")",
        "",
      ].join("\r\n"),
      encoding: "utf8",
      executable: false,
    };
  }

  const fileName = currentPlatform === "darwin"
    ? "Start-Weixin-Codex-Bridge.command"
    : "Start-Weixin-Codex-Bridge.sh";

  return {
    fileName,
    content: [
      "#!/bin/bash",
      `cd "${root}" || exit 1`,
      `if [ -z "$CODEX_BRIDGE_SANDBOX" ]; then export CODEX_BRIDGE_SANDBOX="${resolveDefaultSandbox("", currentPlatform)}"; fi`,
      "npm run start",
      "status=$?",
      "if [ \"$status\" -ne 0 ]; then",
      "  echo",
      "  echo \"Start failed.\"",
      "  read -r -p \"Press Enter to close...\"",
      "fi",
      "",
    ].join("\n"),
    encoding: "utf8",
    executable: true,
  };
}
