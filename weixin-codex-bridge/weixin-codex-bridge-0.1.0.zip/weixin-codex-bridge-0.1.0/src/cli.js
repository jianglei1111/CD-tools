import process from "node:process";

import {
  handleBridgeCommand,
  isBridgeCommand,
  sendWelcomeMessages,
} from "./commands.js";
import { CodexAbortError, CodexRunError, runCodex } from "./codex-runner.js";
import {
  fileWorkspacePrompt,
  recentImagePaths,
  refreshFileWorkspace,
  saveInboundAttachments,
} from "./inbound-media.js";
import {
  DEFAULT_BASE_URL,
  DEFAULT_BOT_TYPE,
  extractText,
  fetchQrCode,
  getQrCodeStatus,
  getUpdates,
  notifyStart,
  notifyStop,
  sendFileAttachment,
  sendImageAttachment,
  sendTextMessage,
} from "./weixin-api.js";
import {
  addPeerAttachments,
  getAccount,
  getActivePeerChat,
  getCodexThreadId,
  getContextToken,
  getLatestPeer,
  getPeerAttachments,
  getPeerSettings,
  getSyncBuf,
  hasWelcomedPeer,
  listRecentTokens,
  loadState,
  markWelcomedPeer,
  resolveStatePath,
  saveAccount,
  setContextToken,
  setCodexThreadId,
  setSyncBuf,
  updatePeerChatById,
  updatePeerSettings,
} from "./state.js";
import { resolveDefaultSandbox } from "./runtime-defaults.js";

const command = process.argv[2] || "help";
const args = parseArgs(process.argv.slice(3));
const runtimeDefaults = {
  model: args.model || process.env.CODEX_BRIDGE_MODEL || "",
  sandbox: resolveDefaultSandbox(args.sandbox || process.env.CODEX_BRIDGE_SANDBOX),
  approval: args.approval || process.env.CODEX_BRIDGE_APPROVAL || "never",
  search: resolveSearchDefault(),
};
const peerRuns = new Map();

try {
  if (command === "login") {
    await login();
  } else if (command === "agent") {
    await agent();
  } else if (command === "status") {
    status();
  } else if (command === "poll") {
    await poll();
  } else if (command === "notify") {
    await notify();
  } else if (command === "send") {
    await send();
  } else if (command === "send-file") {
    await sendFile();
  } else if (command === "send-image") {
    await sendImage();
  } else {
    help();
  }
} catch (err) {
  console.error(err.stack || err.message || String(err));
  process.exitCode = 1;
}

async function login() {
  const localTokenList = listRecentTokens();
  console.log(`requesting Weixin login link from ${DEFAULT_BASE_URL}...`);
  const botType = args["bot-type"] || DEFAULT_BOT_TYPE;
  let qr = await requestAndPrintQr({ localTokenList, botType });
  console.log("waiting for scan/confirmation...");

  let statusBaseUrl = DEFAULT_BASE_URL;
  let pendingVerifyCode;
  let refreshCount = 0;
  const maxRefresh = Number(args["max-refresh"] || 3);
  const timeoutMs = Number(args.timeout || 480000);
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    const status = await getQrCodeStatus({
      qrcode: qr.qrcode,
      baseUrl: statusBaseUrl,
      verifyCode: pendingVerifyCode,
    });

    if (status.status === "wait") {
      process.stdout.write(".");
    } else if (status.status === "scaned") {
      pendingVerifyCode = undefined;
      process.stdout.write("\nscanned; waiting for confirmation...\n");
    } else if (status.status === "scaned_but_redirect") {
      if (status.redirect_host) {
        statusBaseUrl = `https://${status.redirect_host}`;
        process.stdout.write(`\nredirected to ${statusBaseUrl}; continuing...\n`);
      }
    } else if (status.status === "need_verifycode") {
      pendingVerifyCode = await readLine(
        "\nWeChat asks for a numeric verification code. Enter it here: ",
      );
    } else if (status.status === "verify_code_blocked") {
      throw new Error("too many wrong verification code attempts");
    } else if (status.status === "expired") {
      refreshCount += 1;
      if (refreshCount > maxRefresh) {
        throw new Error("login link expired too many times; run login again");
      }
      process.stdout.write(`\nlogin link expired; refreshing (${refreshCount}/${maxRefresh})...\n`);
      qr = await requestAndPrintQr({ localTokenList, botType });
      statusBaseUrl = DEFAULT_BASE_URL;
      pendingVerifyCode = undefined;
    } else if (status.status === "binded_redirect") {
      console.log("\nalready connected to this bridge; existing token should remain valid");
      return;
    } else if (status.status === "confirmed") {
      if (!status.bot_token || !status.ilink_bot_id) {
        throw new Error(`confirmed but missing token/account id: ${JSON.stringify(status)}`);
      }
      saveAccount({
        accountId: status.ilink_bot_id,
        token: status.bot_token,
        baseUrl: status.baseurl || DEFAULT_BASE_URL,
        userId: status.ilink_user_id,
      });
      console.log(`\nconnected. accountId=${status.ilink_bot_id}`);
      console.log(`state saved to ${resolveStatePath()}`);
      return;
    } else {
      console.log(`\nstatus=${JSON.stringify(status)}`);
    }

    await sleep(1000);
  }

  throw new Error("login timed out");
}

async function requestAndPrintQr({ localTokenList, botType }) {
  const qr = await fetchQrCode({ localTokenList, botType });

  if (!qr.qrcode || !qr.qrcode_img_content) {
    throw new Error(`QR response missing qrcode fields: ${JSON.stringify(qr)}`);
  }

  console.log("\nWeixin login link:");
  console.log(qr.qrcode_img_content);
  console.log("\nSend this link to the user immediately. The user should open it and scan/confirm with WeChat.\n");
  return qr;
}

function status() {
  const state = loadState();
  const accountIds = Object.keys(state.accounts);
  console.log(`state: ${resolveStatePath()}`);
  console.log(`latestAccountId: ${state.latestAccountId || "(none)"}`);
  console.log(`accounts: ${accountIds.length}`);
  for (const accountId of accountIds) {
    const account = state.accounts[accountId];
    console.log(
      `- ${accountId} baseUrl=${account.baseUrl || DEFAULT_BASE_URL} userId=${account.userId || "(unknown)"} savedAt=${account.savedAt || "(unknown)"}`,
    );
  }
}

async function poll() {
  const account = getAccount(args.account);
  const once = Boolean(args.once);
  let getUpdatesBuf = getSyncBuf(account.accountId);

  console.log(`polling account=${account.accountId} baseUrl=${account.baseUrl || DEFAULT_BASE_URL}`);
  await notifyStart({ baseUrl: account.baseUrl || DEFAULT_BASE_URL, token: account.token }).catch(
    (err) => console.error(`notifyStart ignored: ${err.message}`),
  );

  const stop = async () => {
    await notifyStop({ baseUrl: account.baseUrl || DEFAULT_BASE_URL, token: account.token }).catch(
      () => {},
    );
  };
  process.once("SIGINT", async () => {
    console.log("\nstopping...");
    await stop();
    process.exit(0);
  });

  do {
    const resp = await getUpdates({
      baseUrl: account.baseUrl || DEFAULT_BASE_URL,
      token: account.token,
      getUpdatesBuf,
      timeoutMs: Number(args.timeout || 35000),
    });

    if ((resp.ret !== undefined && resp.ret !== 0) || (resp.errcode !== undefined && resp.errcode !== 0)) {
      console.error(`getupdates error: ${JSON.stringify(resp)}`);
      if (once) break;
      await sleep(2000);
      continue;
    }

    if (resp.get_updates_buf) {
      getUpdatesBuf = resp.get_updates_buf;
      setSyncBuf(account.accountId, getUpdatesBuf);
    }

    for (const message of resp.msgs || []) {
      if (message.context_token && message.from_user_id) {
        setContextToken(account.accountId, message.from_user_id, message.context_token);
      }
      const text = extractText(message);
      console.log(
        JSON.stringify(
          {
            from: message.from_user_id,
            to: message.to_user_id,
            messageId: message.message_id,
            sessionId: message.session_id,
            itemTypes: (message.item_list || []).map((item) => item.type),
            text,
            hasContextToken: Boolean(message.context_token),
          },
          null,
          2,
        ),
      );
    }

    if (!once) {
      await sleep(500);
    }
  } while (!once);

  await stop();
}

async function agent() {
  const account = getAccount(args.account);
  const defaultCwd = args.cwd || process.env.CODEX_BRIDGE_WORKDIR || process.cwd();
  let getUpdatesBuf = getSyncBuf(account.accountId);
  const pollHealth = createPollHealth();
  console.log(`agent listening account=${account.accountId}`);
  console.log(`codex workdir=${defaultCwd}`);

  await notifyStart({ baseUrl: account.baseUrl || DEFAULT_BASE_URL, token: account.token }).catch(
    (err) => console.error(`notifyStart ignored: ${err.message}`),
  );

  const refreshTimer = startFileWorkspaceRefresh(account.accountId, defaultCwd);
  const stop = async () => {
    clearInterval(refreshTimer);
    await notifyStop({ baseUrl: account.baseUrl || DEFAULT_BASE_URL, token: account.token }).catch(
      () => {},
    );
  };
  process.once("SIGINT", async () => {
    console.log("\nstopping agent...");
    await stop();
    process.exit(0);
  });

  while (true) {
    let resp;
    try {
      resp = await getUpdates({
        baseUrl: account.baseUrl || DEFAULT_BASE_URL,
        token: account.token,
        getUpdatesBuf,
        timeoutMs: Number(args.timeout || 35000),
      });
    } catch (err) {
      await handlePollFailure(account, pollHealth, normalizeThrownPollFailure(err));
      await sleep(pollHealth.nextRetryDelayMs);
      continue;
    }

    const responseFailure = extractPollResponseFailure(resp);
    if (responseFailure) {
      await handlePollFailure(account, pollHealth, responseFailure);
      await sleep(pollHealth.nextRetryDelayMs);
      continue;
    }

    await handlePollRecovery(account, pollHealth);

    if (resp.get_updates_buf) {
      getUpdatesBuf = resp.get_updates_buf;
      setSyncBuf(account.accountId, getUpdatesBuf);
    }

    for (const message of resp.msgs || []) {
      const from = message.from_user_id;
      if (!from) continue;
      const runState = getPeerRunState(account.accountId, from);
      if (message.context_token) {
        setContextToken(account.accountId, from, message.context_token);
      }
      const text = extractText(message).trim();
      const settings = getPeerSettings(account.accountId, from);
      const codexCwd = args.cwd || settings.cwd || defaultCwd;
      const activeChat = getActivePeerChat(account.accountId, from);
      await refreshFileWorkspace(codexCwd).catch((err) => {
        console.error(`file workspace refresh failed: ${err.message || String(err)}`);
      });
      let savedAttachments = [];
      try {
        savedAttachments = await saveInboundAttachments(message, { cwd: codexCwd, text });
      } catch (err) {
        console.error(`attachment save failed: ${err.stack || err.message || String(err)}`);
        await replyLong(account, from, `附件保存失败：${err.message || String(err)}`);
        continue;
      }
      if (savedAttachments.length) {
        addPeerAttachments(account.accountId, from, savedAttachments);
        console.log(`saved attachments from=${from} files=${savedAttachments.map((item) => item.path).join(",")}`);
      }
      if (!text && savedAttachments.length) {
        await reply(account, from, attachmentReceiptText(savedAttachments));
        continue;
      }
      if (!text) continue;

      console.log(`inbound from=${from} text=${JSON.stringify(text)}`);
      const commandHandled = isBridgeCommand(text) && await handleBridgeCommand(text, {
        account,
        from,
        defaultCwd,
        reply: (body) => replyBody(account, from, body),
        sendFile: (filePath, caption) => sendFileToPeer(account, from, filePath, caption),
        sendImage: (filePath, caption) => sendImageToPeer(account, from, filePath, caption),
        runtimeDefaults,
        getRunStatus: () => describeRunState(runState),
        interruptRun: () => interruptPeerRun(runState),
      });
      if (commandHandled) continue;

      if (!hasWelcomedPeer(account.accountId, from)) {
        await sendWelcomeMessages((body) => replyBody(account, from, body));
        markWelcomedPeer(account.accountId, from);
      }

      const turn = createPendingTurn({
        account,
        from,
        text,
        savedAttachments,
        defaultCwd,
        codexCwd,
        settings,
        activeChat,
      });

      if (runState.busy || runState.draining) {
        const enqueueResult = enqueuePendingTurn(runState, turn);
        await replyLong(
          account,
          from,
          enqueueResult === "queued"
            ? "上一条还在处理，这条我先记下了。处理完会继续；发送 /interrupt 可立即中断。"
            : enqueueResult === "merged"
              ? "上一条还在处理，我已把你刚才的新消息并进排队内容。"
              : "上一条还在处理，我已用最新消息替换排队内容。",
        );
        continue;
      }

      startPeerDrain(runState, turn);
    }
  }
}

function getPeerRunState(accountId, from) {
  const key = `${accountId}::${from}`;
  if (!peerRuns.has(key)) {
    peerRuns.set(key, {
      busy: false,
      draining: false,
      controller: null,
      queuedTurn: null,
      currentTurn: null,
    });
  }
  return peerRuns.get(key);
}

function describeRunState(runState) {
  return {
    busy: Boolean(runState?.busy),
    queued: Boolean(runState?.queuedTurn),
    queueLength: runState?.queuedTurn ? 1 : 0,
  };
}

async function interruptPeerRun(runState) {
  if (!runState?.busy || !runState.controller || runState.controller.signal.aborted) {
    return false;
  }
  runState.controller.abort();
  return true;
}

function createPendingTurn({
  account,
  from,
  text,
  savedAttachments,
  defaultCwd,
  codexCwd,
  settings,
  activeChat,
}) {
  const recentAttachments = getPeerAttachments(account.accountId, from);
  const promptAttachments = selectPromptAttachments({
    text,
    currentAttachments: savedAttachments,
    recentAttachments,
  });
  const runConfig = resolveTurnRunConfig(activeChat);
  return {
    account,
    from,
    text,
    settings,
    codexCwd,
    defaultCwd,
    activeChatId: activeChat.id,
    activeChatTitle: activeChat.title,
    compactSeed: activeChat.compactSeed || "",
    combinedTurns: 1,
    runConfig,
    promptAttachments,
  };
}

function resolveTurnRunConfig(activeChat) {
  const chatConfig = activeChat?.runConfig || {};
  return {
    model: chatConfig.model || runtimeDefaults.model || "",
    sandbox: chatConfig.sandbox || runtimeDefaults.sandbox || resolveDefaultSandbox(),
    approval: chatConfig.approval || runtimeDefaults.approval || "never",
    search: chatConfig.search ?? runtimeDefaults.search ?? true,
  };
}

async function drainPeerTurns(runState, initialTurn) {
  let turn = initialTurn;
  while (turn) {
    await executeTurn(runState, turn);
    const next = runState.queuedTurn;
    runState.queuedTurn = null;
    turn = next;
  }
}

function startPeerDrain(runState, initialTurn) {
  if (runState.draining) {
    enqueuePendingTurn(runState, initialTurn);
    return;
  }
  runState.draining = true;
  drainPeerTurns(runState, initialTurn)
    .catch((err) => {
      console.error(err.stack || err.message || String(err));
    })
    .finally(() => {
      runState.draining = false;
      if (runState.queuedTurn) {
        const next = runState.queuedTurn;
        runState.queuedTurn = null;
        if (next) startPeerDrain(runState, next);
      }
    });
}

async function executeTurn(runState, turn) {
  const { account, from, text, settings, codexCwd, promptAttachments, runConfig, activeChatId, compactSeed } = turn;
  runState.busy = true;
  runState.currentTurn = turn;
  runState.controller = new AbortController();

  try {
    await reply(
      account,
      from,
      turn.combinedTurns > 1 ? "收到，正在处理你刚才补充的消息..." : "收到，正在处理...",
    );
    const prompt = buildCodexPrompt(text, from, {
      ...settings,
      cwd: codexCwd,
      attachments: promptAttachments,
      compactSeed,
    });
    const threadId = getCodexThreadId(account.accountId, from, activeChatId);
    const progressReporter = createWeixinProgressReporter(account, from, settings);
    let boundThreadId = threadId;
    const result = await runCodex(prompt, {
      threadId,
      cwd: codexCwd,
      model: runConfig.model,
      sandbox: runConfig.sandbox,
      approval: runConfig.approval,
      search: runConfig.search,
      timeoutMs: args["codex-timeout"],
      images: recentImagePaths(promptAttachments),
      onEvent: (event) => {
        if (event.type === "thread.started" && typeof event.thread_id === "string" && event.thread_id !== boundThreadId) {
          boundThreadId = event.thread_id;
          setCodexThreadId(account.accountId, from, event.thread_id, codexCwd, activeChatId);
          console.log(`bound codex thread user=${from} chat=${activeChatId} thread=${event.thread_id}`);
        }
        progressReporter?.(event);
      },
      signal: runState.controller.signal,
    });
    if (result.threadId && result.threadId !== boundThreadId) {
      setCodexThreadId(account.accountId, from, result.threadId, codexCwd, activeChatId);
      if (result.threadId !== threadId) {
        console.log(`bound codex thread user=${from} chat=${activeChatId} thread=${result.threadId}`);
      }
    }
    if (compactSeed) {
      updatePeerChatById(account.accountId, from, activeChatId, { compactSeed: undefined });
    }
    await replyLong(account, from, result.text);
  } catch (err) {
    if (err instanceof CodexAbortError) {
      await replyLong(
        account,
        from,
        runState.queuedTurn
          ? "已中断当前处理，接下来会继续处理你后面的消息。"
          : "已中断当前处理。你可以继续发新消息。",
      );
    } else {
      console.error(err.details || err.stack || err.message || String(err));
      await replyLong(account, from, formatCodexFailureForWeixin(err));
    }
  } finally {
    await refreshFileWorkspace(codexCwd).catch((err) => {
      console.error(`file workspace refresh failed: ${err.message || String(err)}`);
    });
    runState.busy = false;
    runState.currentTurn = null;
    runState.controller = null;
  }
}

function startFileWorkspaceRefresh(accountId, defaultCwd) {
  const configured = Number(args["file-refresh-interval"] || process.env.WEIXIN_CODEX_FILE_REFRESH_MS);
  const intervalMs = Number.isFinite(configured) && configured > 0 ? configured : 60000;
  const timer = setInterval(() => {
    refreshKnownFileWorkspaces(accountId, defaultCwd).catch((err) => {
      console.error(`file workspace periodic refresh failed: ${err.message || String(err)}`);
    });
  }, Math.max(intervalMs, 5000));
  timer.unref?.();
  return timer;
}

async function refreshKnownFileWorkspaces(accountId, defaultCwd) {
  const state = loadState();
  const dirs = new Set([defaultCwd]);
  for (const settings of Object.values(state.peerSettings?.[accountId] || {})) {
    if (settings?.cwd) dirs.add(settings.cwd);
  }
  for (const bucket of Object.values(state.peerChats?.[accountId] || {})) {
    for (const chat of bucket?.chats || []) {
      if (chat?.cwd) dirs.add(chat.cwd);
    }
  }
  for (const cwd of dirs) {
    await refreshFileWorkspace(cwd);
  }
}

function attachmentReceiptText(attachments) {
  const kinds = new Set((attachments || []).map((item) => item.kind));
  if (kinds.size === 1 && kinds.has("image")) return "已收到图片";
  if (kinds.size === 1 && kinds.has("video")) return "已收到视频";
  if (kinds.size === 1 && kinds.has("voice")) return "已收到语音";
  if (kinds.size === 1 && kinds.has("file")) return "已收到文件";
  return "已收到附件";
}

function selectPromptAttachments({ text, currentAttachments = [], recentAttachments = [] }) {
  if (currentAttachments.length) {
    return currentAttachments;
  }
  if (messageMentionsAttachment(text)) {
    return recentAttachments;
  }
  return [];
}

function messageMentionsAttachment(text) {
  const normalized = String(text || "").trim().toLowerCase();
  if (!normalized) return false;
  return [
    "这个文件",
    "那个文件",
    "刚才那个文件",
    "这个图片",
    "那张图片",
    "这张图片",
    "刚才那张图",
    "这个附件",
    "刚才的附件",
    "这份文档",
    "上一张图",
    "上一个文件",
    "this file",
    "that file",
    "this image",
    "that image",
    "this attachment",
    "last file",
    "last image",
    "attached file",
    "attached image",
  ].some((needle) => normalized.includes(needle));
}

function resolveSearchDefault() {
  if (args.search === true || args.search === "true" || args.search === "1") {
    return true;
  }
  if (args.search === false || args.search === "false" || args.search === "0") {
    return false;
  }
  const envValue = String(process.env.CODEX_BRIDGE_SEARCH || "").trim().toLowerCase();
  if (envValue === "0" || envValue === "false" || envValue === "off" || envValue === "disabled") {
    return false;
  }
  return true;
}

function createPollHealth() {
  return {
    consecutiveFailures: 0,
    firstFailureAt: 0,
    lastFailureAt: 0,
    lastFailureSummary: "",
    lastNotifiedSummary: "",
    degraded: false,
    degradedNoticeSent: false,
    nextRetryDelayMs: 2000,
  };
}

function extractPollResponseFailure(resp) {
  if ((resp.ret === undefined || resp.ret === 0) && (resp.errcode === undefined || resp.errcode === 0)) {
    return undefined;
  }
  const message = firstNonEmpty([
    resp.errmsg,
    resp.msg,
    resp.message,
    JSON.stringify(resp),
  ]) || "getupdates returned an error response";
  return normalizePollFailure({
    source: "response",
    message,
  });
}

function normalizeThrownPollFailure(err) {
  return normalizePollFailure({
    source: "exception",
    message: err?.message || String(err),
  });
}

function normalizePollFailure(input) {
  const message = String(input?.message || "").trim() || "unknown getupdates error";
  const lower = message.toLowerCase();
  const kind = isAuthFailureText(lower)
    ? "reauth"
    : isNetworkFailureText(lower)
      ? "network"
      : "server";
  return {
    kind,
    source: input?.source || "unknown",
    message,
    summary: summarizePollFailure(kind, message),
  };
}

function isAuthFailureText(text) {
  return [
    "401",
    "403",
    "token",
    "auth",
    "unauthorized",
    "forbidden",
    "login expired",
  ].some((part) => text.includes(part));
}

function isNetworkFailureText(text) {
  return [
    "fetch failed",
    "econnreset",
    "econnrefused",
    "enotfound",
    "etimedout",
    "network",
    "socket hang up",
    "timeout",
  ].some((part) => text.includes(part));
}

function summarizePollFailure(kind, message) {
  if (kind === "reauth") {
    return `登录可能已失效：${message}`;
  }
  if (kind === "network") {
    return `网络异常：${message}`;
  }
  return `微信服务异常：${message}`;
}

async function handlePollFailure(account, pollHealth, failure) {
  pollHealth.consecutiveFailures += 1;
  pollHealth.lastFailureAt = Date.now();
  if (!pollHealth.firstFailureAt) {
    pollHealth.firstFailureAt = pollHealth.lastFailureAt;
  }
  pollHealth.lastFailureSummary = failure.summary;
  pollHealth.nextRetryDelayMs = Math.min(30000, 2000 * Math.max(1, pollHealth.consecutiveFailures));
  console.error(`getupdates error (${failure.kind}): ${failure.message}`);

  const shouldNotify = failure.kind === "reauth" || pollHealth.consecutiveFailures >= 2;
  if (!shouldNotify) return;

  const degradedChanged = !pollHealth.degraded;
  const summaryChanged = pollHealth.lastNotifiedSummary !== failure.summary;
  pollHealth.degraded = true;
  if (!degradedChanged && !summaryChanged) return;

  const notice = buildPollFailureNotice(failure);
  const delivered = await notifyStatusPeers(account, notice);
  pollHealth.degradedNoticeSent = delivered || pollHealth.degradedNoticeSent;
  pollHealth.lastNotifiedSummary = failure.summary;
}

async function handlePollRecovery(account, pollHealth) {
  if (!pollHealth.consecutiveFailures) return;

  const degraded = pollHealth.degraded;
  const outageStartedAt = pollHealth.firstFailureAt;
  const outageEndedAt = Date.now();
  const degradedNoticeSent = pollHealth.degradedNoticeSent;
  const previousSummary = pollHealth.lastFailureSummary;
  pollHealth.consecutiveFailures = 0;
  pollHealth.firstFailureAt = 0;
  pollHealth.lastFailureAt = 0;
  pollHealth.lastFailureSummary = "";
  pollHealth.degraded = false;
  pollHealth.degradedNoticeSent = false;
  pollHealth.lastNotifiedSummary = "";
  pollHealth.nextRetryDelayMs = 2000;

  if (!degraded) return;

  console.log(`getupdates recovered after: ${previousSummary}`);
  if (!degradedNoticeSent && outageEndedAt - outageStartedAt < 15000) return;

  const durationText = formatDuration(outageEndedAt - outageStartedAt);
  await notifyStatusPeers(
    account,
    `微信桥接连接已恢复。刚才异常持续约 ${durationText}；如果你在这段时间发过消息，我可能没有收到，请再发一次。`,
  );
}

function buildPollFailureNotice(failure) {
  if (failure.kind === "reauth") {
    return "微信桥接当前已掉线，可能是登录失效。请在电脑上重新执行 npm run login，然后再运行 npm run start。恢复前我可能无法继续回复。";
  }
  if (failure.kind === "network") {
    return "微信桥接当前网络异常，正在自动重试。异常期间你发来的消息我可能收不到，建议稍后补发一次。";
  }
  return "微信桥接当前与微信服务通信异常，正在自动重试。异常期间你发来的消息我可能收不到，建议稍后补发一次。";
}

async function notifyStatusPeers(account, text) {
  const peers = collectStatusPeerIds(account.accountId);
  if (!peers.length) return false;

  let delivered = false;
  for (const peerId of peers) {
    try {
      await replyLong(account, peerId, text);
      delivered = true;
    } catch (err) {
      console.error(`status notice failed peer=${peerId}: ${err.message || String(err)}`);
    }
  }
  return delivered;
}

function collectStatusPeerIds(accountId) {
  const peers = new Set();
  const latestPeer = getLatestPeer(accountId);
  if (latestPeer) peers.add(latestPeer);

  for (const [key, runState] of peerRuns.entries()) {
    if (!key.startsWith(`${accountId}::`)) continue;
    if (!runState.busy && !runState.queuedTurn) continue;
    const peerId = key.slice(`${accountId}::`.length);
    if (peerId) peers.add(peerId);
  }

  return [...peers];
}

function formatDuration(ms) {
  const totalSeconds = Math.max(1, Math.round(ms / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  if (!minutes) return `${seconds} 秒`;
  if (!seconds) return `${minutes} 分钟`;
  return `${minutes} 分 ${seconds} 秒`;
}

function firstNonEmpty(values) {
  return values.find((value) => typeof value === "string" && value.trim());
}

function enqueuePendingTurn(runState, turn) {
  const existing = runState.queuedTurn;
  if (!existing) {
    runState.queuedTurn = turn;
    return "queued";
  }
  if (canMergeQueuedTurn(existing, turn)) {
    runState.queuedTurn = mergeQueuedTurn(existing, turn);
    return "merged";
  }
  runState.queuedTurn = turn;
  return "replaced";
}

function canMergeQueuedTurn(existing, incoming) {
  return existing.activeChatId === incoming.activeChatId && existing.codexCwd === incoming.codexCwd;
}

function mergeQueuedTurn(existing, incoming) {
  return {
    ...existing,
    text: mergeTurnText(existing.text, incoming.text),
    settings: incoming.settings,
    codexCwd: incoming.codexCwd,
    defaultCwd: incoming.defaultCwd,
    activeChatTitle: incoming.activeChatTitle,
    compactSeed: existing.compactSeed || incoming.compactSeed || "",
    combinedTurns: (existing.combinedTurns || 1) + 1,
    runConfig: incoming.runConfig,
    promptAttachments: mergeTurnAttachments(existing.promptAttachments, incoming.promptAttachments),
  };
}

function mergeTurnText(existingText, incomingText) {
  const first = String(existingText || "").trim();
  const second = String(incomingText || "").trim();
  if (!first) return second;
  if (!second) return first;
  return `${first}\n\n[用户补充消息]\n${second}`;
}

function mergeTurnAttachments(existing = [], incoming = []) {
  const seen = new Set();
  const merged = [];
  for (const item of [...existing, ...incoming]) {
    const key = item?.path || item?.sourceUrl || item?.originalName || JSON.stringify(item);
    if (seen.has(key)) continue;
    seen.add(key);
    merged.push(item);
  }
  return merged;
}

function formatCodexFailureForWeixin(err) {
  if (err instanceof CodexRunError && err.message) {
    return err.message;
  }
  return `Codex 执行失败：${err?.message || String(err)}`;
}

async function send() {
  const account = getAccount(args.account);
  const to = args.to;
  const text = args.text;
  if (!to || !text) {
    throw new Error("send requires --to '<user@im.wechat>' and --text '<message>'");
  }
  const contextToken = args["context-token"] || getContextToken(account.accountId, to);
  const result = await sendTextMessage({
    baseUrl: account.baseUrl || DEFAULT_BASE_URL,
    token: account.token,
    to,
    text,
    contextToken,
  });
  console.log(`sent messageId=${result.messageId} contextToken=${contextToken ? "yes" : "no"}`);
}

async function sendFile() {
  const account = getAccount(args.account);
  const to = args.to;
  const filePath = args.file;
  if (!to || !filePath) {
    throw new Error("send-file requires --to '<user@im.wechat>' and --file '<path>'");
  }
  const contextToken = args["context-token"] || getContextToken(account.accountId, to);
  const result = await sendFileAttachment({
    baseUrl: account.baseUrl || DEFAULT_BASE_URL,
    token: account.token,
    to,
    filePath,
    fileName: args.name,
    text: args.text || "",
    contextToken,
  });
  console.log(`sent file messageId=${result.messageId} contextToken=${contextToken ? "yes" : "no"}`);
}

async function sendImage() {
  const account = getAccount(args.account);
  const to = args.to;
  const filePath = args.file;
  if (!to || !filePath) {
    throw new Error("send-image requires --to '<user@im.wechat>' and --file '<path>'");
  }
  const contextToken = args["context-token"] || getContextToken(account.accountId, to);
  const result = await sendImageAttachment({
    baseUrl: account.baseUrl || DEFAULT_BASE_URL,
    token: account.token,
    to,
    filePath,
    text: args.text || "",
    contextToken,
  });
  console.log(`sent image messageId=${result.messageId} contextToken=${contextToken ? "yes" : "no"}`);
}

async function sendFileToPeer(account, to, filePath, text = "") {
  const contextToken = getContextToken(account.accountId, to);
  const result = await sendFileAttachment({
    baseUrl: account.baseUrl || DEFAULT_BASE_URL,
    token: account.token,
    to,
    filePath,
    text,
    contextToken,
  });
  return result;
}

async function sendImageToPeer(account, to, filePath, text = "") {
  const contextToken = getContextToken(account.accountId, to);
  const result = await sendImageAttachment({
    baseUrl: account.baseUrl || DEFAULT_BASE_URL,
    token: account.token,
    to,
    filePath,
    text,
    contextToken,
  });
  return result;
}

async function notify() {
  const account = getAccount(args.account);
  const to = args.to || getLatestPeer(account.accountId);
  const text = args.text || process.argv.slice(3).filter((part) => !part.startsWith("--")).join(" ");
  if (!to) {
    throw new Error("notify needs --to, or at least one previously received Weixin message");
  }
  if (!text) {
    throw new Error("notify requires --text '<message>'");
  }
  await replyLong(account, to, text);
  console.log(`notified to=${to}`);
}

async function reply(account, to, text) {
  const contextToken = getContextToken(account.accountId, to);
  return sendTextMessage({
    baseUrl: account.baseUrl || DEFAULT_BASE_URL,
    token: account.token,
    to,
    text,
    contextToken,
  });
}

async function replyBody(account, to, body) {
  if (Array.isArray(body)) {
    return replyItems(account, to, body);
  }
  return replyLong(account, to, body);
}

async function replyItems(account, to, texts) {
  const contextToken = getContextToken(account.accountId, to);
  return sendTextMessage({
    baseUrl: account.baseUrl || DEFAULT_BASE_URL,
    token: account.token,
    to,
    texts,
    contextToken,
  });
}

async function replyLong(account, to, text) {
  const chunks = chunkText(String(text || ""), 3500);
  for (const chunk of chunks) {
    await reply(account, to, chunk);
  }
}

function buildCodexPrompt(text, from, settings = {}) {
  return [
    "$weixin-codex",
    "你正在通过微信为用户提供 Codex 助手服务。",
    "请直接回答用户消息。若需要修改代码，可以在当前仓库执行必要命令。",
    "如果需要把生成的图片发给当前微信用户，用图片消息发送：npm run send-image -- --to '<微信用户ID>' --file '<图片路径>' --text '<可选说明>'。其他文件才用 send-file。",
    "只有在发送命令成功返回 sent image/sent file 后，才能告诉用户已经发送；失败时说明失败原因。",
    "最终回复会原样发回微信，所以保持简洁、可读，不要包含不必要的运行日志。",
    `微信用户: ${from}`,
    `当前工作目录: ${settings.cwd || process.cwd()}`,
    fileWorkspacePrompt(settings.cwd || process.cwd(), settings.attachments || []),
    settings.compactSeed ? `上下文提示: ${settings.compactSeed}` : "",
    "",
    "用户消息:",
    text,
  ].filter(Boolean).join("\n");
}

function createWeixinProgressReporter(account, to, settings = {}) {
  if (args.progress === "false" || process.env.WEIXIN_CODEX_PROGRESS === "0") {
    return undefined;
  }
  if (settings.progress === false) {
    return undefined;
  }

  let lastSentAt = 0;
  let pendingAgentMessage;
  const minIntervalMs = Number(args["progress-interval"] || process.env.WEIXIN_CODEX_PROGRESS_INTERVAL_MS || 6000);

  return (event) => {
    if (isPotentialFinalAgentMessage(event)) {
      pendingAgentMessage = shortenOneLine(event.item.text, 100);
      return;
    }

    if (event.type === "turn.completed") {
      pendingAgentMessage = undefined;
      return;
    }

    const toolLine = summarizeToolProgressEvent(event);
    if (toolLine && pendingAgentMessage) {
      sendThought(account, to, pendingAgentMessage);
      pendingAgentMessage = undefined;
      return;
    }

    const line = summarizeCodexEvent(event);
    if (!line) return;

    const now = Date.now();
    const immediate = event.type === "thread.started" || event.type === "turn.started";
    if (!immediate && now - lastSentAt < minIntervalMs) return;

    lastSentAt = now;
    sendThought(account, to, line);
  };
}

function sendThought(account, to, line) {
  replyLong(account, to, line).catch((err) => {
    console.error(`progress send failed: ${err.message || String(err)}`);
  });
}

function isPotentialFinalAgentMessage(event) {
  return event.type === "item.completed" && event.item?.type === "agent_message" && event.item?.text;
}

function summarizeToolProgressEvent(event) {
  const item = event.item || {};
  if (event.type !== "item.started" && event.type !== "item.completed") return undefined;
  if (item.type === "command_execution") return "tool";
  if (item.type === "file_change") return "tool";
  if (item.type === "web_search") return "tool";
  return undefined;
}

function summarizeCodexEvent(event) {
  if (event.type === "thread.started") {
    return undefined;
  }
  if (event.type === "turn.started") {
    return undefined;
  }
  if (event.type === "turn.completed") {
    return undefined;
  }
  if (event.type === "item.started") {
    return undefined;
  }
  if (event.type === "item.completed") {
    const item = event.item || {};
    return undefined;
  }
  return undefined;
}

function shortenOneLine(value, maxLen) {
  const line = String(value).replace(/\s+/g, " ").trim();
  if (line.length <= maxLen) return line;
  return `${line.slice(0, maxLen - 1)}…`;
}

function help() {
  console.log(`Usage:
  npm run agent -- [--cwd <dir>] [--model <model>]
  npm run login
  npm run notify -- --text <message> [--to <user@im.wechat>]
  npm run status
  npm run poll -- [--once] [--account <id>]
  npm run send -- --to <user@im.wechat> --text <message> [--account <id>]
  npm run send-image -- --to <user@im.wechat> --file <path> [--text <caption>] [--account <id>]
  node src/cli.js send-file --to <user@im.wechat> --file <path> [--name <name>] [--text <caption>] [--account <id>]
`);
}

function parseArgs(raw) {
  const parsed = {};
  for (let i = 0; i < raw.length; i += 1) {
    const part = raw[i];
    if (!part.startsWith("--")) continue;
    const key = part.slice(2);
    const next = raw[i + 1];
    if (!next || next.startsWith("--")) {
      parsed[key] = true;
    } else {
      parsed[key] = next;
      i += 1;
    }
  }
  return parsed;
}

function readLine(prompt) {
  process.stdout.write(prompt);
  return new Promise((resolve) => {
    process.stdin.resume();
    process.stdin.setEncoding("utf8");
    process.stdin.once("data", (chunk) => {
      process.stdin.pause();
      resolve(String(chunk).trim());
    });
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function chunkText(text, maxLen) {
  if (!text) return [""];
  const chunks = [];
  for (let i = 0; i < text.length; i += maxLen) {
    chunks.push(text.slice(i, i + maxLen));
  }
  return chunks;
}
