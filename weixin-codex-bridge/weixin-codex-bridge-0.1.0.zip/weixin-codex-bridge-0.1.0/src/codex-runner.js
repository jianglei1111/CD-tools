import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { isWindowsSandboxStartupFailure, resolveDefaultSandbox } from "./runtime-defaults.js";

export class CodexRunError extends Error {
  constructor(message, details) {
    super(message);
    this.name = "CodexRunError";
    this.details = details;
  }
}

export class CodexAbortError extends Error {
  constructor(message = "codex interrupted") {
    super(message);
    this.name = "CodexAbortError";
  }
}

export async function runCodex(prompt, options = {}) {
  const cwd = path.resolve(options.cwd || process.env.CODEX_BRIDGE_WORKDIR || process.cwd());
  const outputPath = path.join(
    os.tmpdir(),
    `weixin-codex-last-${Date.now()}-${Math.random().toString(16).slice(2)}.txt`,
  );
  const codexBin = process.env.CODEX_BIN || "codex";
  const args = buildCodexArgs({
    cwd,
    outputPath,
    prompt,
    threadId: options.threadId,
    model: options.model,
    sandbox: options.sandbox,
    approval: options.approval,
    search: options.search,
    images: options.images,
  });

  const result = await runProcess(codexBin, args, {
    cwd,
    timeoutMs: Number(options.timeoutMs || process.env.CODEX_BRIDGE_TIMEOUT_MS || 600000),
    onEvent: options.onEvent,
    signal: options.signal,
  });

  let lastMessage = "";
  try {
    lastMessage = (await fs.readFile(outputPath, "utf8")).trim();
  } catch {
    // Fall back to stdout below.
  } finally {
    await fs.unlink(outputPath).catch(() => {});
  }

  if (result.exitCode !== 0) {
    const details = [result.stderr.trim(), result.stdout.trim()].filter(Boolean).join("\n");
    throw buildCodexRunError(result.exitCode, details, result.stdout, result.stderr);
  }

  return {
    text: lastMessage || result.stdout.trim() || "(Codex returned no final message)",
    threadId: parseThreadId(result.stdout) || options.threadId,
    stdout: result.stdout,
    stderr: result.stderr,
  };
}

function buildCodexArgs(options) {
  const webSearchMode = resolveWebSearchMode(options.search);
  const common = [
    "--skip-git-repo-check",
    "--output-last-message",
    options.outputPath,
    "-c",
    `sandbox_mode=${toTomlString(resolveDefaultSandbox(options.sandbox || process.env.CODEX_BRIDGE_SANDBOX))}`,
    "-c",
    `approval_policy=${toTomlString(options.approval || process.env.CODEX_BRIDGE_APPROVAL || "never")}`,
  ];

  if (webSearchMode) {
    common.push("-c", `web_search=${toTomlString(webSearchMode)}`);
  }

  if (options.model || process.env.CODEX_BRIDGE_MODEL) {
    common.push("--model", options.model || process.env.CODEX_BRIDGE_MODEL);
  }

  for (const image of options.images || []) {
    common.push("--image", image);
  }

  if (options.threadId) {
    return [
      "exec",
      "resume",
      "--json",
      "--all",
      ...common,
      options.threadId,
      options.prompt,
    ];
  }

  return [
    "exec",
    "--json",
    "--cd",
    options.cwd,
    ...common,
    options.prompt,
  ];
}

function resolveWebSearchMode(search) {
  if (search === true) return "live";
  if (search === false) return "disabled";

  const envValue = String(process.env.CODEX_BRIDGE_SEARCH || "").trim().toLowerCase();
  if (!envValue) return undefined;
  if (envValue === "1" || envValue === "true" || envValue === "on" || envValue === "live") {
    return "live";
  }
  if (envValue === "cached") {
    return "cached";
  }
  if (envValue === "0" || envValue === "false" || envValue === "off" || envValue === "disabled") {
    return "disabled";
  }
  return undefined;
}

function toTomlString(value) {
  return JSON.stringify(String(value));
}

function parseThreadId(stdout) {
  for (const line of stdout.split(/\r?\n/)) {
    if (!line.trim().startsWith("{")) continue;
    try {
      const event = JSON.parse(line);
      if (event.type === "thread.started" && typeof event.thread_id === "string") {
        return event.thread_id;
      }
    } catch {
      // Ignore non-event lines.
    }
  }
  return undefined;
}

function runProcess(command, args, options) {
  return new Promise((resolve, reject) => {
    if (options.signal?.aborted) {
      reject(new CodexAbortError());
      return;
    }

    const child = spawn(command, args, {
      cwd: options.cwd,
      env: process.env,
      stdio: ["ignore", "pipe", "pipe"],
      windowsHide: true,
    });
    let stdout = "";
    let stderr = "";
    let stdoutRemainder = "";
    let settled = false;

    const timeout = setTimeout(() => {
      child.kill("SIGTERM");
      settleReject(new Error(`codex timed out after ${options.timeoutMs}ms`));
    }, options.timeoutMs);

    const abortHandler = () => {
      child.kill("SIGTERM");
      setTimeout(() => {
        if (!child.killed) {
          child.kill("SIGKILL");
        }
      }, 3000).unref?.();
      settleReject(new CodexAbortError());
    };

    if (options.signal) {
      options.signal.addEventListener("abort", abortHandler, { once: true });
    }

    child.stdout.on("data", (chunk) => {
      const text = chunk.toString();
      stdout += text;
      stdoutRemainder = consumeJsonLines(stdoutRemainder + text, options.onEvent);
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk.toString();
    });
    child.on("error", (err) => {
      settleReject(err);
    });
    child.on("close", (exitCode) => {
      consumeJsonLines(`${stdoutRemainder}\n`, options.onEvent);
      settleResolve({ exitCode, stdout, stderr });
    });

    function cleanup() {
      clearTimeout(timeout);
      if (options.signal) {
        options.signal.removeEventListener("abort", abortHandler);
      }
    }

    function settleResolve(value) {
      if (settled) return;
      settled = true;
      cleanup();
      resolve(value);
    }

    function settleReject(err) {
      if (settled) return;
      settled = true;
      cleanup();
      reject(err);
    }
  });
}

function consumeJsonLines(buffer, onEvent) {
  const lines = buffer.split(/\r?\n/);
  const remainder = lines.pop() ?? "";
  if (!onEvent) return remainder;
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("{")) continue;
    try {
      onEvent(JSON.parse(trimmed));
    } catch {
      // Ignore non-JSON output.
    }
  }
  return remainder;
}

function buildCodexRunError(exitCode, details, stdout, stderr) {
  const rawMessage = extractJsonFailureMessage(stdout)
    || firstMeaningfulLine(stderr)
    || firstMeaningfulNonJsonLine(stdout)
    || `codex exited with ${exitCode}`;
  const message = normalizeCodexFailureMessage(rawMessage);
  const fullDetails = `codex exited with ${exitCode}${details ? `\n${details}` : ""}`;
  return new CodexRunError(message, fullDetails);
}

function extractJsonFailureMessage(stdout) {
  let lastError;
  for (const line of String(stdout || "").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("{")) continue;
    try {
      const event = JSON.parse(trimmed);
      if (event.type === "turn.failed" && event.error?.message) {
        return String(event.error.message);
      }
      if (event.type === "error" && event.message) {
        lastError = String(event.message);
      }
    } catch {
      // Ignore malformed JSON event lines.
    }
  }
  return lastError;
}

function firstMeaningfulNonJsonLine(stdout) {
  for (const line of String(stdout || "").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("{")) continue;
    return trimmed;
  }
  return "";
}

function firstMeaningfulLine(text) {
  for (const line of String(text || "").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    return trimmed;
  }
  return "";
}

function normalizeCodexFailureMessage(message) {
  const text = String(message || "").trim();
  if (!text) {
    return "Codex 执行失败。";
  }
  if (text.includes("Upstream access forbidden") && text.includes("sub.7clong.net")) {
    return "Codex 服务连接失败：当前上游接口 sub.7clong.net 返回 502，访问被拒绝。";
  }
  if (text.includes("Upstream access forbidden")) {
    return "Codex 服务连接失败：当前上游接口返回 502，访问被拒绝。";
  }
  if (isWindowsSandboxStartupFailure(text)) {
    return "Codex 本地执行失败：Windows sandbox 没启动起来，本地工具还没开始运行。请先重试；如果仍失败，把当前对话沙箱设为 danger-full-access 后再试。";
  }
  if (text.includes("Not inside a trusted directory")) {
    return "Codex 无法在当前目录执行：目录未被信任。";
  }
  return text.length > 240 ? `${text.slice(0, 239)}...` : text;
}
