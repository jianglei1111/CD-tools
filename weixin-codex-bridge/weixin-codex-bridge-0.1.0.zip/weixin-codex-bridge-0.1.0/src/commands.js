import fs from "node:fs";
import os from "node:os";
import path from "node:path";

import { listCodexHistory } from "./codex-history.js";
import {
  formatAttachmentSummary,
  listWorkspaceFiles,
  resolveFileWorkspace,
} from "./inbound-media.js";
import {
  clearPeerAttachments,
  clearCodexThreadId,
  createPeerChat,
  getActivePeerChat,
  getPeerSettings,
  listPeerChats,
  markWelcomedPeer,
  renameActivePeerChat,
  switchPeerChat,
  updateActivePeerChat,
  upsertPeerChatFromThread,
  updatePeerSettings,
} from "./state.js";
import { resolveDefaultSandbox } from "./runtime-defaults.js";

const SANDBOX_OPTIONS = ["read-only", "workspace-write", "danger-full-access"];
const APPROVAL_OPTIONS = ["never", "on-request", "on-failure", "untrusted"];
const COMPACT_SEED = "这是由微信指令 /compact 创建的新对话。请保留当前微信用户的目标和最近任务背景，后续继续简洁协作。";

const COMMON_COMMAND_LINES = [
  "/help 查看全部命令",
  "/skills [关键词] 查看可用 skills",
  "/interrupt 中断当前处理",
  "/settings 查看当前设置",
  "/status 查看当前目录、对话、进度",
  "/cwd 查看当前工作目录",
  "/cwd <目录> 切换工作目录",
  "/new 新建一条 Codex 对话",
  "/sendimage <路径> [说明] 以图片消息发送服务器图片到当前微信",
  "/sendfile <路径> [说明] 发送服务器文件到当前微信",
  "/attach list 查看最近图片/文件",
];

const ADVANCED_COMMAND_LINES = [
  "/chat list 查看本机所有 Codex 对话",
  "/chat new [名称] 新建并切换对话",
  "/chat use <编号|名称|threadId> 切换对话并自动切目录",
  "/chat sync 手动同步本机 Codex 历史会话",
  "/chat rename <名称> 重命名当前对话",
  "/chat current 查看当前对话",
  "/attach clear 清空最近附件引用，不删除文件",
  "/compact 新建对话并带上简短上下文摘要",
  "/settings sandbox <模式> 设置沙箱",
  "/settings approval <策略> 设置审批策略",
  "/settings search on|off 开关搜索",
  "/settings model <模型|default> 设置模型",
  "/settings reset 重置当前对话设置",
  "/progress on|off 开关中间阶段消息",
];

const WELCOME_LINE_BREAK = "\u2028";

export const WELCOME_MESSAGES = [
  "👋 欢迎使用 CD Code 技术生态\n我是你的微信-Codex 助手。直接发需求、图片、文件都可以。",
  [
    "常用命令：",
    "/help 查看全部命令",
    "/status 查看当前状态",
    "/new 新建一条对话",
    "/interrupt 中断当前处理",
    "/settings 查看当前设置",
    "",
    "更多技术内容：www.chedankj.com",
  ].join(WELCOME_LINE_BREAK),
];

export const HELP_TEXT = [
  "CD Code 技术生态 · 微信-Codex 助手",
  "",
  "直接发消息即可开始；图片、文件也可以直接发，发完说“处理这个”即可。",
  "",
  "常用命令：",
  ...COMMON_COMMAND_LINES,
  "",
  "进阶命令：",
  ...ADVANCED_COMMAND_LINES,
  "",
  "官网：www.chedankj.com",
].join("\n");

export function isBridgeCommand(text) {
  return text.trim().startsWith("/");
}

export async function handleBridgeCommand(text, ctx) {
  const trimmed = text.trim();
  const [command, ...restParts] = trimmed.split(/\s+/);
  const rest = restParts.join(" ").trim();

  if (command === "/start") {
    markWelcomedPeer(ctx.account.accountId, ctx.from);
    await sendWelcomeMessages(ctx.reply);
    return true;
  }

  if (command === "/help") {
    markWelcomedPeer(ctx.account.accountId, ctx.from);
    await ctx.reply(HELP_TEXT);
    return true;
  }

  if (command === "/status") {
    const settings = getPeerSettings(ctx.account.accountId, ctx.from);
    const chat = getActivePeerChat(ctx.account.accountId, ctx.from);
    const runStatus = ctx.getRunStatus?.() || { busy: false, queued: false };
    const runConfig = getEffectiveRunConfig(ctx);
    await ctx.reply([
      `目录：${settings.cwd || ctx.defaultCwd || process.cwd()}`,
      `对话：${chat.title} (${chat.threadId || "尚未创建"})`,
      `进度：${settings.progress === false ? "off" : "on"}`,
      `处理：${formatRunStatus(runStatus)}`,
      `沙箱：${runConfig.sandbox}`,
      `审批：${runConfig.approval}`,
      `搜索：${runConfig.search ? "on" : "off"}`,
      `模型：${runConfig.model || "default"}`,
    ].join("\n"));
    return true;
  }

  if (command === "/skills") {
    await handleSkillsCommand(rest, ctx);
    return true;
  }

  if (command === "/interrupt") {
    await handleInterruptCommand(ctx);
    return true;
  }

  if (command === "/settings") {
    await handleSettingsCommand(restParts, ctx);
    return true;
  }

  if (command === "/cwd") {
    if (!rest) {
      const settings = getPeerSettings(ctx.account.accountId, ctx.from);
      await ctx.reply(settings.cwd || ctx.defaultCwd || process.cwd());
      return true;
    }
    const cwd = resolveUserPath(rest);
    if (!isDirectory(cwd)) {
      await ctx.reply(`目录不存在：${cwd}`);
      return true;
    }
    updatePeerSettings(ctx.account.accountId, ctx.from, { cwd });
    clearCodexThreadId(ctx.account.accountId, ctx.from);
    updateActivePeerChat(ctx.account.accountId, ctx.from, { cwd });
    await ctx.reply(`已切换目录并新建 Codex 对话：${cwd}`);
    return true;
  }

  if (command === "/new") {
    const settings = getPeerSettings(ctx.account.accountId, ctx.from);
    createPeerChat(ctx.account.accountId, ctx.from, rest, { cwd: settings.cwd || ctx.defaultCwd || process.cwd() });
    await ctx.reply("已新建 Codex 对话。");
    return true;
  }

  if (command === "/chat") {
    await handleChatCommand(restParts, ctx);
    return true;
  }

  if (command === "/attach") {
    await handleAttachCommand(restParts, ctx);
    return true;
  }

  if (command === "/compact") {
    clearCodexThreadId(ctx.account.accountId, ctx.from);
    updateActivePeerChat(ctx.account.accountId, ctx.from, {
      compactSeed: COMPACT_SEED,
    });
    await ctx.reply("已压缩为新对话，后续会带上简短上下文提示。");
    return true;
  }

  if (command === "/progress") {
    const value = rest.toLowerCase();
    if (value !== "on" && value !== "off") {
      await ctx.reply("用法：/progress on 或 /progress off");
      return true;
    }
    updatePeerSettings(ctx.account.accountId, ctx.from, { progress: value === "on" });
    await ctx.reply(`进度消息已${value === "on" ? "开启" : "关闭"}。`);
    return true;
  }

  if (command === "/sendfile") {
    if (!rest) {
      await ctx.reply("用法：/sendfile <服务器文件路径> [说明]");
      return true;
    }
    const [filePathRaw, ...captionParts] = restParts;
    const filePath = path.resolve(filePathRaw);
    const caption = captionParts.join(" ");
    await ctx.sendFile(filePath, caption);
    return true;
  }

  if (command === "/sendimage") {
    if (!rest) {
      await ctx.reply("用法：/sendimage <服务器图片路径> [说明]");
      return true;
    }
    if (typeof ctx.sendImage !== "function") {
      await ctx.reply("当前桥接版本不支持图片消息发送。");
      return true;
    }
    const [filePathRaw, ...captionParts] = restParts;
    const filePath = path.resolve(filePathRaw);
    const caption = captionParts.join(" ");
    await ctx.sendImage(filePath, caption);
    return true;
  }

  await ctx.reply(`未知指令：${command}\n发送 /help 查看可用指令。`);
  return true;
}

async function handleChatCommand(parts, ctx) {
  const sub = parts[0] || "list";
  const rest = parts.slice(1).join(" ").trim();
  const accountId = ctx.account.accountId;
  const from = ctx.from;

  if (sub === "list") {
    syncCodexHistory(accountId, from);
    const active = getActivePeerChat(accountId, from);
    const chats = listPeerChats(accountId, from);
    const lines = chats.map((chat, index) => {
      const marker = chat.id === active.id ? "*" : " ";
      const thread = chat.threadId ? chat.threadId.slice(0, 8) : "(new)";
      const cwd = chat.cwd ? `\n   ${chat.cwd}` : "";
      return `${marker}${index + 1}. ${chat.title} ${thread}${cwd}`;
    });
    await ctx.reply(lines.length ? lines.join("\n") : "暂无对话。");
    return;
  }

  if (sub === "sync") {
    const imported = syncCodexHistory(accountId, from);
    await ctx.reply(imported > 0 ? `已同步 ${imported} 条本机 Codex 会话。` : "没有发现可同步的 Codex 会话。");
    return;
  }

  if (sub === "new") {
    const settings = getPeerSettings(accountId, from);
    const chat = createPeerChat(accountId, from, rest, { cwd: settings.cwd || ctx.defaultCwd || process.cwd() });
    await ctx.reply(`已新建并切换到：${chat.title}`);
    return;
  }

  if (sub === "use") {
    if (!rest) {
      await ctx.reply("用法：/chat use <编号|名称|threadId>");
      return;
    }
    syncCodexHistory(accountId, from);
    const chat = switchPeerChat(accountId, from, rest);
    if (chat?.cwd) {
      updatePeerSettings(accountId, from, { cwd: chat.cwd });
    }
    await ctx.reply(chat ? `已切换到：${chat.title}${chat.cwd ? `\n目录：${chat.cwd}` : ""}\n${buildSettingsText(ctx, { includeChat: false })}` : "未找到该对话。");
    return;
  }

  if (sub === "rename") {
    if (!rest) {
      await ctx.reply("用法：/chat rename <名称>");
      return;
    }
    const chat = renameActivePeerChat(accountId, from, rest);
    await ctx.reply(`已重命名当前对话：${chat.title}`);
    return;
  }

  if (sub === "current") {
    const chat = getActivePeerChat(accountId, from);
    await ctx.reply([
      `当前对话：${chat.title}`,
      `thread：${chat.threadId || "(尚未创建)"}`,
      `目录：${chat.cwd || getPeerSettings(accountId, from).cwd || ctx.defaultCwd || process.cwd()}`,
      buildSettingsText(ctx, { includeChat: false }),
    ].join("\n"));
    return;
  }

  await ctx.reply("用法：/chat list | sync | new [名称] | use <编号|名称|threadId> | rename <名称> | current");
}

async function handleAttachCommand(parts, ctx) {
  const sub = parts[0] || "list";
  const accountId = ctx.account.accountId;
  const from = ctx.from;

  if (sub === "list") {
    const cwd = getPeerSettings(accountId, from).cwd || ctx.defaultCwd || process.cwd();
    const files = await listWorkspaceFiles(cwd, 10);
    await ctx.reply(files.length ? formatAttachmentSummary(files) : `暂无文件目录记录：${resolveFileWorkspace(cwd)}`);
    return;
  }

  if (sub === "clear") {
    clearPeerAttachments(accountId, from);
    const cwd = getPeerSettings(accountId, from).cwd || ctx.defaultCwd || process.cwd();
    await ctx.reply(`已清空最近附件引用。文件目录不会删除：${resolveFileWorkspace(cwd)}`);
    return;
  }

  await ctx.reply("用法：/attach list | clear");
}

export async function sendWelcomeMessages(reply) {
  for (const message of WELCOME_MESSAGES) {
    await reply(message);
  }
}

async function handleInterruptCommand(ctx) {
  const interrupted = await ctx.interruptRun?.();
  if (interrupted) {
    await ctx.reply("收到，正在中断当前处理…");
    return;
  }
  await ctx.reply("当前没有正在处理的任务。");
}

async function handleSkillsCommand(rest, ctx) {
  const filter = String(rest || "").trim().toLowerCase();
  const skills = listAvailableSkills()
    .filter((skill) => {
      if (!filter) return true;
      const haystack = [
        skill.name,
        skill.scope,
        skill.description,
      ].filter(Boolean).join(" ").toLowerCase();
      return haystack.includes(filter);
    })
    .sort((a, b) => a.name.localeCompare(b.name, "zh-CN"));

  if (!skills.length) {
    await ctx.reply(filter ? `没有匹配的 skill：${rest}` : "当前机器上没有发现可用 skill。");
    return;
  }

  const lines = [
    filter ? `匹配到 ${skills.length} 个 skill：` : `当前可用 skills（${skills.length}）：`,
    ...skills.map((skill) => {
      const scopeLabel = skill.scope === "system" ? "系统" : "本地";
      const desc = skill.description ? `\n   ${skill.description}` : "";
      return `- ${skill.name} [${scopeLabel}]${desc}`;
    }),
    "",
    "使用时可直接在消息里写：$skill名",
  ];
  await ctx.reply(lines.join("\n"));
}

async function handleSettingsCommand(parts, ctx) {
  const sub = (parts[0] || "show").toLowerCase();
  const rest = parts.slice(1).join(" ").trim();

  if (sub === "show") {
    await ctx.reply(buildSettingsText(ctx));
    return;
  }

  if (sub === "reset") {
    updateActivePeerChat(ctx.account.accountId, ctx.from, { runConfig: {} });
    await ctx.reply(`已重置当前对话设置。\n${buildSettingsText(ctx)}`);
    return;
  }

  if (sub === "sandbox") {
    const value = rest.toLowerCase();
    if (!SANDBOX_OPTIONS.includes(value)) {
      await ctx.reply(`用法：/settings sandbox ${SANDBOX_OPTIONS.join("|")}`);
      return;
    }
    updateRunConfig(ctx, { sandbox: value });
    await ctx.reply(`已设置沙箱：${value}`);
    return;
  }

  if (sub === "approval") {
    const value = rest.toLowerCase();
    if (!APPROVAL_OPTIONS.includes(value)) {
      await ctx.reply(`用法：/settings approval ${APPROVAL_OPTIONS.join("|")}`);
      return;
    }
    updateRunConfig(ctx, { approval: value });
    await ctx.reply(`已设置审批策略：${value}`);
    return;
  }

  if (sub === "search") {
    const value = rest.toLowerCase();
    if (value !== "on" && value !== "off") {
      await ctx.reply("用法：/settings search on|off");
      return;
    }
    updateRunConfig(ctx, { search: value === "on" });
    await ctx.reply(`搜索已${value === "on" ? "开启" : "关闭"}。`);
    return;
  }

  if (sub === "model") {
    if (!rest) {
      await ctx.reply("用法：/settings model <模型名|default>");
      return;
    }
    updateRunConfig(ctx, { model: rest === "default" ? undefined : rest });
    await ctx.reply(`已设置模型：${rest === "default" ? "default" : rest}`);
    return;
  }

  await ctx.reply([
    "用法：",
    "/settings",
    "/settings reset",
    `/settings sandbox ${SANDBOX_OPTIONS.join("|")}`,
    `/settings approval ${APPROVAL_OPTIONS.join("|")}`,
    "/settings search on|off",
    "/settings model <模型名|default>",
  ].join("\n"));
}

function syncCodexHistory(accountId, from) {
  const sessions = listCodexHistory();
  let count = 0;
  for (const session of sessions) {
    upsertPeerChatFromThread(accountId, from, session.threadId, session.title, {
      cwd: session.cwd,
      sourcePath: session.sourcePath,
    });
    count += 1;
  }
  return count;
}

function resolveUserPath(value) {
  const raw = String(value || "").trim();
  if (raw === "~") return os.homedir();
  if (raw.startsWith("~/")) return path.join(os.homedir(), raw.slice(2));
  return path.resolve(raw);
}

function isDirectory(value) {
  try {
    return fs.statSync(value).isDirectory();
  } catch {
    return false;
  }
}

function buildSettingsText(ctx, options = {}) {
  const runConfig = getEffectiveRunConfig(ctx);
  const chat = getActivePeerChat(ctx.account.accountId, ctx.from);
  const lines = [
    `沙箱：${runConfig.sandbox}`,
    `审批：${runConfig.approval}`,
    `搜索：${runConfig.search ? "on" : "off"}`,
    `模型：${runConfig.model || "default"}`,
  ];
  if (options.includeChat !== false) {
    lines.unshift(`当前对话：${chat.title}`);
  }
  return lines.join("\n");
}

function getEffectiveRunConfig(ctx) {
  const chat = getActivePeerChat(ctx.account.accountId, ctx.from);
  const chatConfig = chat.runConfig || {};
  const defaults = ctx.runtimeDefaults || {};
  return {
    sandbox: chatConfig.sandbox || defaults.sandbox || resolveDefaultSandbox(),
    approval: chatConfig.approval || defaults.approval || "never",
    search: chatConfig.search ?? defaults.search ?? true,
    model: chatConfig.model || defaults.model || "",
  };
}

function updateRunConfig(ctx, patch) {
  const chat = getActivePeerChat(ctx.account.accountId, ctx.from);
  const current = chat.runConfig || {};
  const next = {
    ...current,
    ...patch,
  };
  if (patch.model === undefined) {
    delete next.model;
  }
  updateActivePeerChat(ctx.account.accountId, ctx.from, { runConfig: next });
}

function formatRunStatus(status) {
  if (!status?.busy) {
    return "idle";
  }
  if (status.queueLength > 0) {
    return `处理中，排队 ${status.queueLength} 条`;
  }
  return "处理中";
}

function listAvailableSkills() {
  const skillsDir = resolveCodexSkillsDir();
  if (!isDirectory(skillsDir)) {
    return [];
  }

  const result = [];
  collectSkillEntries(skillsDir, "local", result);

  const systemDir = path.join(skillsDir, ".system");
  if (isDirectory(systemDir)) {
    collectSkillEntries(systemDir, "system", result);
  }

  const byName = new Map();
  for (const skill of result) {
    const existing = byName.get(skill.name);
    if (!existing || existing.scope === "system") {
      byName.set(skill.name, skill);
    }
  }
  return [...byName.values()];
}

function collectSkillEntries(rootDir, scope, output) {
  let dirents = [];
  try {
    dirents = fs.readdirSync(rootDir, { withFileTypes: true });
  } catch {
    return;
  }

  for (const dirent of dirents) {
    if (!dirent.isDirectory()) continue;
    const skillDir = path.join(rootDir, dirent.name);
    const skillFile = path.join(skillDir, "SKILL.md");
    if (!fs.existsSync(skillFile)) continue;
    output.push(readSkillMeta(skillFile, dirent.name, scope));
  }
}

function readSkillMeta(skillFile, fallbackName, scope) {
  try {
    const text = fs.readFileSync(skillFile, "utf8");
    const frontmatterMatch = text.match(/^---\n([\s\S]*?)\n---/);
    const frontmatter = frontmatterMatch?.[1] || "";
    const name = matchFrontmatterValue(frontmatter, "name") || fallbackName;
    const description = matchFrontmatterValue(frontmatter, "description") || "";
    return { name, description, scope };
  } catch {
    return { name: fallbackName, description: "", scope };
  }
}

function matchFrontmatterValue(frontmatter, key) {
  const match = String(frontmatter || "").match(new RegExp(`^${key}:\\s*(.+)$`, "m"));
  return match?.[1]?.trim().replace(/^['"]|['"]$/g, "") || "";
}

function resolveCodexSkillsDir() {
  const codexHome = process.env.CODEX_HOME || path.join(process.env.HOME || os.homedir(), ".codex");
  return path.join(codexHome, "skills");
}
