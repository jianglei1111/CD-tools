import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";

export const DEFAULT_BASE_URL = "https://ilinkai.weixin.qq.com";
export const WEIXIN_PLUGIN_VERSION = "2.4.3";
export const DEFAULT_BOT_TYPE = "3";
export const DEFAULT_CDN_BASE_URL = "https://novac2c.cdn.weixin.qq.com/c2c";

export const MessageType = {
  USER: 1,
  BOT: 2,
};

export const MessageItemType = {
  TEXT: 1,
  IMAGE: 2,
  VOICE: 3,
  FILE: 4,
  VIDEO: 5,
};

export const MessageState = {
  NEW: 0,
  GENERATING: 1,
  FINISH: 2,
};

export const UploadMediaType = {
  IMAGE: 1,
  VIDEO: 2,
  FILE: 3,
  VOICE: 4,
};

function ensureTrailingSlash(url) {
  return url.endsWith("/") ? url : `${url}/`;
}

function buildClientVersion(version) {
  const [major = 0, minor = 0, patch = 0] = version
    .split(".")
    .map((part) => Number.parseInt(part, 10) || 0);
  return ((major & 0xff) << 16) | ((minor & 0xff) << 8) | (patch & 0xff);
}

function randomWechatUin() {
  const uint32 = crypto.randomBytes(4).readUInt32BE(0);
  return Buffer.from(String(uint32), "utf8").toString("base64");
}

function commonHeaders() {
  const headers = {
    "iLink-App-Id": "bot",
    "iLink-App-ClientVersion": String(buildClientVersion(WEIXIN_PLUGIN_VERSION)),
  };
  if (process.env.WEIXIN_ROUTE_TAG?.trim()) {
    headers.SKRouteTag = process.env.WEIXIN_ROUTE_TAG.trim();
  }
  return headers;
}

function jsonHeaders(token) {
  return {
    "Content-Type": "application/json",
    AuthorizationType: "ilink_bot_token",
    "X-WECHAT-UIN": randomWechatUin(),
    ...commonHeaders(),
    ...(token?.trim() ? { Authorization: `Bearer ${token.trim()}` } : {}),
  };
}

function baseInfo() {
  return {
    channel_version: WEIXIN_PLUGIN_VERSION,
    bot_agent: process.env.WEIXIN_BOT_AGENT || "WeixinCodexBridge/0.1.0",
  };
}

export async function apiGet({ baseUrl = DEFAULT_BASE_URL, endpoint, timeoutMs = 35000 }) {
  const url = new URL(endpoint, ensureTrailingSlash(baseUrl));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "GET",
      headers: commonHeaders(),
      signal: controller.signal,
    });
    const text = await res.text();
    if (!res.ok) {
      throw new Error(`GET ${endpoint} failed: ${res.status} ${text}`);
    }
    return text ? JSON.parse(text) : {};
  } finally {
    clearTimeout(timer);
  }
}

export async function apiPost({
  baseUrl = DEFAULT_BASE_URL,
  endpoint,
  body,
  token,
  timeoutMs = 35000,
}) {
  const url = new URL(endpoint, ensureTrailingSlash(baseUrl));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: jsonHeaders(token),
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await res.text();
    if (!res.ok) {
      throw new Error(`POST ${endpoint} failed: ${res.status} ${text}`);
    }
    return text ? JSON.parse(text) : {};
  } finally {
    clearTimeout(timer);
  }
}

async function apiPostOctetStream({
  url,
  body,
  timeoutMs = 35000,
}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/octet-stream" },
      body: new Uint8Array(body),
      signal: controller.signal,
    });
    if (res.status !== 200) {
      const errMsg = res.headers.get("x-error-message") || (await res.text());
      throw new Error(`CDN upload failed: ${res.status} ${errMsg}`);
    }
    const downloadParam = res.headers.get("x-encrypted-param");
    if (!downloadParam) {
      throw new Error("CDN upload response missing x-encrypted-param header");
    }
    return { downloadParam };
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchQrCode({ localTokenList = [], botType = DEFAULT_BOT_TYPE } = {}) {
  return apiPost({
    baseUrl: DEFAULT_BASE_URL,
    endpoint: `ilink/bot/get_bot_qrcode?bot_type=${encodeURIComponent(botType)}`,
    body: { local_token_list: localTokenList },
  });
}

export async function getQrCodeStatus({ qrcode, baseUrl = DEFAULT_BASE_URL, verifyCode }) {
  let endpoint = `ilink/bot/get_qrcode_status?qrcode=${encodeURIComponent(qrcode)}`;
  if (verifyCode) {
    endpoint += `&verify_code=${encodeURIComponent(verifyCode)}`;
  }
  return apiGet({ baseUrl, endpoint, timeoutMs: 35000 });
}

export async function getUpdates({ baseUrl, token, getUpdatesBuf = "", timeoutMs = 35000 }) {
  try {
    return await apiPost({
      baseUrl,
      endpoint: "ilink/bot/getupdates",
      token,
      timeoutMs,
      body: {
        get_updates_buf: getUpdatesBuf,
        base_info: baseInfo(),
      },
    });
  } catch (err) {
    if (err.name === "AbortError") {
      return { ret: 0, msgs: [], get_updates_buf: getUpdatesBuf };
    }
    throw err;
  }
}

export async function sendTextMessage({ baseUrl, token, to, text, texts, contextToken }) {
  const clientId = `weixin-codex-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
  const itemList = buildTextItemList({ text, texts });
  await apiPost({
    baseUrl,
    endpoint: "ilink/bot/sendmessage",
    token,
    timeoutMs: 15000,
    body: {
      msg: {
        from_user_id: "",
        to_user_id: to,
        client_id: clientId,
        message_type: MessageType.BOT,
        message_state: MessageState.FINISH,
        item_list: itemList.length ? itemList : undefined,
        context_token: contextToken || undefined,
      },
      base_info: baseInfo(),
    },
  });
  return { messageId: clientId };
}

function buildTextItemList({ text, texts }) {
  if (Array.isArray(texts)) {
    return texts
      .map((value) => String(value || "").trim())
      .filter(Boolean)
      .map((value) => ({
        type: MessageItemType.TEXT,
        text_item: { text: value },
      }));
  }

  if (!text) return [];
  return [
    {
      type: MessageItemType.TEXT,
      text_item: { text },
    },
  ];
}

export async function getUploadUrl({
  baseUrl,
  token,
  filekey,
  mediaType,
  toUserId,
  rawsize,
  rawfilemd5,
  filesize,
  aeskey,
}) {
  return apiPost({
    baseUrl,
    endpoint: "ilink/bot/getuploadurl",
    token,
    timeoutMs: 15000,
    body: {
      filekey,
      media_type: mediaType,
      to_user_id: toUserId,
      rawsize,
      rawfilemd5,
      filesize,
      no_need_thumb: true,
      aeskey,
      base_info: baseInfo(),
    },
  });
}

export async function sendFileAttachment({
  baseUrl,
  token,
  to,
  filePath,
  fileName = path.basename(filePath),
  text = "",
  contextToken,
  cdnBaseUrl = DEFAULT_CDN_BASE_URL,
}) {
  const uploaded = await uploadFileAttachmentToWeixin({
    baseUrl,
    token,
    to,
    filePath,
    cdnBaseUrl,
  });
  return sendFileMessage({
    baseUrl,
    token,
    to,
    text,
    fileName,
    uploaded,
    contextToken,
  });
}

export async function sendImageAttachment({
  baseUrl,
  token,
  to,
  filePath,
  text = "",
  contextToken,
  cdnBaseUrl = DEFAULT_CDN_BASE_URL,
}) {
  const uploaded = await uploadImageToWeixin({
    baseUrl,
    token,
    to,
    filePath,
    cdnBaseUrl,
  });
  return sendImageMessage({
    baseUrl,
    token,
    to,
    text,
    uploaded,
    contextToken,
  });
}

async function uploadFileAttachmentToWeixin({ baseUrl, token, to, filePath, cdnBaseUrl }) {
  return uploadEncryptedMediaToWeixin({
    baseUrl,
    token,
    to,
    filePath,
    cdnBaseUrl,
    mediaType: UploadMediaType.FILE,
  });
}

async function uploadImageToWeixin({ baseUrl, token, to, filePath, cdnBaseUrl }) {
  return uploadEncryptedMediaToWeixin({
    baseUrl,
    token,
    to,
    filePath,
    cdnBaseUrl,
    mediaType: UploadMediaType.IMAGE,
  });
}

async function uploadEncryptedMediaToWeixin({ baseUrl, token, to, filePath, cdnBaseUrl, mediaType }) {
  const plaintext = await fs.readFile(filePath);
  const rawsize = plaintext.length;
  const rawfilemd5 = crypto.createHash("md5").update(plaintext).digest("hex");
  const filesize = aesEcbPaddedSize(rawsize);
  const filekey = crypto.randomBytes(16).toString("hex");
  const aeskey = crypto.randomBytes(16);

  const uploadUrlResp = await getUploadUrl({
    baseUrl,
    token,
    filekey,
    mediaType,
    toUserId: to,
    rawsize,
    rawfilemd5,
    filesize,
    aeskey: aeskey.toString("hex"),
  });

  const uploadFullUrl = uploadUrlResp.upload_full_url?.trim();
  const uploadParam = uploadUrlResp.upload_param;
  if (!uploadFullUrl && !uploadParam) {
    throw new Error(`getuploadurl returned no upload URL: ${JSON.stringify(uploadUrlResp)}`);
  }

  const encrypted = encryptAesEcb(plaintext, aeskey);
  const cdnUrl =
    uploadFullUrl ||
    `${cdnBaseUrl}/upload?encrypted_query_param=${encodeURIComponent(uploadParam)}&filekey=${encodeURIComponent(filekey)}`;
  const { downloadParam } = await apiPostOctetStream({ url: cdnUrl, body: encrypted });

  return {
    filekey,
    downloadEncryptedQueryParam: downloadParam,
    aeskey: aeskey.toString("hex"),
    fileSize: rawsize,
    fileSizeCiphertext: filesize,
  };
}

async function sendFileMessage({ baseUrl, token, to, text, fileName, uploaded, contextToken }) {
  const items = [];
  if (text) {
    items.push({ type: MessageItemType.TEXT, text_item: { text } });
  }
  items.push({
    type: MessageItemType.FILE,
    file_item: {
      media: {
        encrypt_query_param: uploaded.downloadEncryptedQueryParam,
        aes_key: Buffer.from(uploaded.aeskey).toString("base64"),
        encrypt_type: 1,
      },
      file_name: fileName,
      len: String(uploaded.fileSize),
    },
  });

  let lastClientId = "";
  for (const item of items) {
    lastClientId = `weixin-codex-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
    await apiPost({
      baseUrl,
      endpoint: "ilink/bot/sendmessage",
      token,
      timeoutMs: 15000,
      body: {
        msg: {
          from_user_id: "",
          to_user_id: to,
          client_id: lastClientId,
          message_type: MessageType.BOT,
          message_state: MessageState.FINISH,
          item_list: [item],
          context_token: contextToken || undefined,
        },
        base_info: baseInfo(),
      },
    });
  }

  return { messageId: lastClientId };
}

async function sendImageMessage({ baseUrl, token, to, text, uploaded, contextToken }) {
  const items = [];
  if (text) {
    items.push({ type: MessageItemType.TEXT, text_item: { text } });
  }
  items.push({
    type: MessageItemType.IMAGE,
    image_item: {
      media: {
        encrypt_query_param: uploaded.downloadEncryptedQueryParam,
        aes_key: Buffer.from(uploaded.aeskey).toString("base64"),
        encrypt_type: 1,
      },
      mid_size: uploaded.fileSizeCiphertext,
    },
  });

  let lastClientId = "";
  for (const item of items) {
    lastClientId = `weixin-codex-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
    await apiPost({
      baseUrl,
      endpoint: "ilink/bot/sendmessage",
      token,
      timeoutMs: 15000,
      body: {
        msg: {
          from_user_id: "",
          to_user_id: to,
          client_id: lastClientId,
          message_type: MessageType.BOT,
          message_state: MessageState.FINISH,
          item_list: [item],
          context_token: contextToken || undefined,
        },
        base_info: baseInfo(),
      },
    });
  }

  return { messageId: lastClientId };
}

function encryptAesEcb(plaintext, key) {
  const cipher = crypto.createCipheriv("aes-128-ecb", key, null);
  return Buffer.concat([cipher.update(plaintext), cipher.final()]);
}

function aesEcbPaddedSize(plaintextSize) {
  return Math.ceil((plaintextSize + 1) / 16) * 16;
}

export async function notifyStart({ baseUrl, token }) {
  return apiPost({
    baseUrl,
    endpoint: "ilink/bot/msg/notifystart",
    token,
    timeoutMs: 10000,
    body: { base_info: baseInfo() },
  });
}

export async function notifyStop({ baseUrl, token }) {
  return apiPost({
    baseUrl,
    endpoint: "ilink/bot/msg/notifystop",
    token,
    timeoutMs: 10000,
    body: { base_info: baseInfo() },
  });
}

export function extractText(message) {
  for (const item of message.item_list || []) {
    if (item.type === MessageItemType.TEXT && item.text_item?.text != null) {
      return String(item.text_item.text);
    }
    if (item.type === MessageItemType.VOICE && item.voice_item?.text) {
      return String(item.voice_item.text);
    }
  }
  return "";
}
