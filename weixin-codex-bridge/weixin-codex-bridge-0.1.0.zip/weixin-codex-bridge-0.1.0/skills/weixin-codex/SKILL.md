---
name: weixin-codex
description: Use when Codex is responding to a user through the weixin-codex-bridge WeChat integration, including handling WeChat chat UX, sending files back through the bridge, and respecting bridge commands/state.
---

# Weixin Codex Bridge

You are responding through a WeChat chat, not a terminal UI.

## Reply Style

- Keep final replies concise and directly useful.
- Do not mention hidden reasoning or internal event names.
- If you need time, send a short visible status sentence before doing work.
- Avoid long logs in final replies. Summarize what changed and how to verify.

## Bridge Commands Users Can Send

The bridge handles these before your prompt reaches Codex:

- `/help` show usage
- `/status` show current directory, Codex thread, progress setting
- `/cwd <dir>` set Codex working directory
- `/new` start a new Codex thread
- `/chat list` sync and list all local Codex sessions across directories
- `/chat sync` manually import local Codex sessions into the WeChat conversation list
- `/chat new [name]` create and switch to a conversation
- `/chat use <number|name|threadId>` switch conversation and restore its working directory
- `/chat rename <name>` rename current conversation
- `/chat current` show current conversation
- `/attach list` show recent files in the WeChat file workspace
- `/attach clear` clear recent attachment references without deleting files
- `/compact` start a new thread with a short continuity seed
- `/progress on|off` toggle intermediate status messages
- `/sendimage <path> [caption]` send a server image to WeChat as an inline image message
- `/sendfile <path> [caption]` send a server file to WeChat

## Files Back To WeChat

If you create an image that should appear inline in the WeChat chat, send it as an image message:

```bash
npm run send-image -- --to '<WEIXIN_USER_ID>' --file '<ABSOLUTE_IMAGE_PATH>' --text '<optional caption>'
```

Use `send-image` for PNG/JPEG/WebP/GIF image outputs. Do not use `send-file` for images unless the user explicitly asks for a file attachment.

For non-image files such as PDF, DOCX, ZIP, logs, or source archives, run:

```bash
npm run send-file -- --to '<WEIXIN_USER_ID>' --file '<ABSOLUTE_FILE_PATH>' --text '<optional caption>'
```

Use the exact WeChat user id provided in the prompt. Prefer absolute paths. Treat the send as complete only after the command exits successfully and prints `sent image` or `sent file`. If the command fails, do not tell the user the file was sent; report the failure or retry the correct command.

## Working Directory

Respect the bridge-provided working directory. If the user asks to switch projects, tell them to use `/cwd <dir>` or run only within the configured directory.

## Runtime Defaults

When connected through WeChat, the bridge defaults to `sandbox=danger-full-access`, `approval=never`, `search=on`, and progress messages on. A saved per-conversation `/settings` override can still change these; `/settings reset` returns that conversation to defaults.

## Inbound Attachments

Images and files sent from WeChat are saved under `weixin-files/` in the active working directory. That directory is created after the first inbound file. Check `weixin-files/README.md` and `weixin-files/files.json` when the user says "this image", "this file", "刚才那个文件", or similar. The index includes receive time, modify time, size, MIME type, existence, and readable filenames. It refreshes on message receive, after Codex tasks, and periodically while the agent runs. If you create outputs related to these files, prefer writing them back into `weixin-files/` so the index can track them. Recent images may also be attached to the Codex invocation with `--image`.

## Image Generation And Editing

- If the user asks for image generation, image editing, logo/poster/artwork production, or says to process a WeChat image, use the installed `$chedan-image2` skill.
- Follow `$chedan-image2` for its key handling and command flow. In particular, require a user-provided `image` group key from `https://www.chedankj.com`, pass it only through the current command environment, and report real HTTP errors back to the user.
- For edit requests that refer to a recently received WeChat image, combine the attachment context from `weixin-files/` with `$chedan-image2`.

## Safety

- Do not expose tokens, `.state/weixin-state.json`, auth files, or other secrets.
- Do not run destructive commands unless the user explicitly asks and the risk is clear.
- For long file-generation tasks, prefer creating an artifact and sending it with `send-image` for images or `send-file` for other files.
