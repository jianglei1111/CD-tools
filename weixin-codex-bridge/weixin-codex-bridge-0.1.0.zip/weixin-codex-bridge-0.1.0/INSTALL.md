# 安装说明

这是一个本地运行的微信-Codex 桥接器。

这个安装包不会带出打包者本地的 Codex 配置、登录状态或运行状态。
安装时使用当前这台机器自己的本地 Codex 环境。

## 需要准备的环境

这个包是“微信桥接器”。它运行时需要 Node.js、npm、Codex CLI 和当前用户的 Codex 配置。
如果你把安装交给 Codex，Codex 需要负责把这些环境检查到可用：缺少就安装，已有但不能用就修复。
如果你手动安装，就需要你自己先把这些环境准备到可用。

需要验证到可用的环境：

- Node.js `>= 18.17`
- `npm`
- `codex` 命令，并且终端里可以直接执行
- 当前用户自己的 `~/.codex/config.toml`
- 其中 `base_url` 必须为：

```toml
base_url = "https://www.chedankj.com"
```

安装负责人需要先跑一遍：

```bash
node -v
npm -v
codex --version
```

如果这三个命令里有任何一个不能运行，先把那一项安装或修复到可用，再继续安装桥接器。
如果 `node.exe` 报 `Access is denied`，需要修复 Node.js 安装、PATH 或当前用户执行权限，直到当前用户能正常执行 `node -v`。

补充：

- `npm` 通常随 Node.js 一起安装
- `codex` 需要按当前机器适合的方式安装或修复，确保命令可用
- `~/.codex/config.toml` 和其中的 `base_url` 需要检查、创建或修正到要求值

## 方式一：直接交给 Codex 安装

把整个压缩包或解压后的目录交给 Codex，然后让它按
`INSTALL_WITH_CODEX.md`
完成安装。

如果你只是想复制一句提示词给 Codex，直接用
`ASK_CODEX_TO_INSTALL.txt` 里的内容。

## 方式二：手动安装

前提：

- Node.js >= 18.17
- `codex` 命令已可用
- Codex 本身已经能正常使用
- 当前机器的 `~/.codex/config.toml` 里需要有：

```toml
base_url = "https://www.chedankj.com"
```

如果不是这个地址，请先去官网查看安装教程，再继续安装。

步骤：

```bash
cd weixin-codex-bridge
node scripts/bootstrap.js
npm run login
npm run start
```

说明：

1. `node scripts/bootstrap.js` 会检查环境、安装依赖、安装微信 skill，并在桌面或当前用户目录创建一个可双击的启动脚本。
2. `npm run login` 会打印微信登录链接；把这个链接发给用户，让用户点开后扫码/确认登录。
3. `npm run start` 会启动后台 agent；只有 agent 在运行时，微信消息才会被接收并转给 Codex。
4. 连接成功后，在微信里发送 `/help` 就能开始使用。

推荐你把安装理解成 3 步：

1. 环境必须先通过
2. 登录链接必须先发给用户完成扫码
3. 后台 agent 必须启动成功，微信消息才会进 Codex

## 运行沙箱

- 当前版本在所有平台上默认都使用 `danger-full-access` 作为运行沙箱。
- 通过微信连接时，默认运行状态是全打开：`sandbox=danger-full-access`、`approval=never`、`搜索=on`、进度消息=on。
- 这样做是为了尽量避免本地工具、Python 脚本、图片 skill 等任务在执行层被 sandbox 卡住。
- 如果你后面手动改过某个微信对话的 `/settings`，那条对话会优先使用它自己的保存设置，不会被安装默认值强行覆盖。
- 如果你怀疑某个旧对话还在沿用旧设置，去微信里发送 `/settings` 查看；需要恢复默认时发送 `/settings reset`。

## Windows 说明

- Windows 上请优先用 `npm run start` 或安装时自动生成的 `Start-Weixin-Codex-Bridge.cmd` 启动。
- 正常情况下，用户在微信里发消息时，不应该每次都弹出新的黑色命令行窗口。
- 安装脚本会尽量隐藏后台运行时拉起的子进程窗口；如果你仍看到反复弹窗，先更新到新版安装包，然后执行：

```bash
npm run stop
npm run start
```

## 启动与重启

- 这个项目需要后台 agent 运行，不能只装不启动。
- 当前版本不是系统服务，也不会自动注册开机自启。
- 如果电脑重启，agent 会停止。
- 电脑重启后，重新双击桌面或用户目录里的启动脚本，或进入安装目录执行：

```bash
npm run start
```

- 一般不需要重新扫码登录，除非微信登录状态失效。

## 扫码登录说明

- 当前版本不在终端里生成二维码，只输出登录链接。
- 如果是 Codex 帮用户安装，Codex 运行 `npm run login` 后，要第一时间把终端输出的 `Weixin login link` 发给用户。
- 用户点开该链接后，按页面提示用微信扫码或确认即可。
- 登录链接会过期；过期后重新运行 `npm run login`。

## 常用命令

```bash
npm run status
npm run stop
node scripts/doctor.js
node scripts/doctor.js --probe-codex
node scripts/package-release.js
```

如果安装过程中卡住，优先看这几项：

1. `codex --version` 能不能正常执行
2. `~/.codex/config.toml` 是否存在
3. `base_url` 是否为 `https://www.chedankj.com`
4. `npm run login` 输出的登录链接是否已经及时发给用户
5. `npm run start` 后再执行一次 `node src/service.js status` 看服务是否真的起来

## 补充

- 微信图片和文件会保存到当前工作目录的 `weixin-files/`
- bridge 会自动给每次微信对话注入 `$weixin-codex`
- 用户不需要手动告诉 Codex “你现在在微信里”
- 安装时会自动在桌面或用户目录放一个可双击启动的脚本
