# weixin-codex-bridge

Minimal Tencent Weixin iLink Bot API client extracted from the OpenClaw
`@tencent-weixin/openclaw-weixin` plugin path.

This repo is meant to be shipped as a local installable package that lets
Codex talk to a WeChat user through the Weixin iLink Bot API.

The package does not carry the packager's local Codex config, account state,
or runtime state. Installation uses the receiver's own local Codex environment.

For Codex-assisted installation, Codex is responsible for preparing the runtime
environment before installing the bridge: verify Node.js, npm, Codex CLI, and
the receiver's Codex provider config; install missing pieces; repair unusable
commands, PATH, versions, or permissions; then verify again. For example, if
`node.exe` reports `Access is denied`, repair Node.js installation, PATH, or
the current user's execute permission until `node -v` works.

It currently provides this minimum useful surface:

- login-link flow via `get_bot_qrcode` and `get_qrcode_status`
- credential storage in `.state/weixin-state.json`
- long-poll receive via `getupdates`
- text send via `sendmessage`
- file attachment send via `getuploadurl` + encrypted CDN upload + `sendmessage`
- inbound WeChat image/file download into the active Codex working directory
- Codex agent mode that reuses one Codex thread per Weixin peer

## Quick Start

If you want Codex to install this package for you:

1. Give Codex the unpacked folder
2. Ask it to follow `INSTALL_WITH_CODEX.md`
3. Or paste the contents of `ASK_CODEX_TO_INSTALL.txt`

The intended Codex-assisted install flow is:

1. check and repair Node.js/npm/Codex/config until usable
2. run `node scripts/bootstrap.js`
3. run `npm run login` and immediately send the login link to the user
4. run `npm run start`

If you want to install manually:

```bash
node scripts/bootstrap.js
npm run login
npm run start
```

Then send `/help` to the connected WeChat bot.

## Main Commands

```bash
npm install
npm run bootstrap
npm run doctor
npm run install-skill
npm run login
npm run status
npm run poll -- --once
npm run send -- --to '<user@im.wechat>' --text 'hello'
npm run send-file -- --to '<user@im.wechat>' --file ./example.docx
npm run agent
npm run start
npm run stop
```

State files may contain Weixin bot tokens, so `.state/` is git-ignored.

`node scripts/bootstrap.js` checks the environment, installs npm dependencies,
installs the bundled `weixin-codex` skill into `$CODEX_HOME/skills`, and creates
a clickable launcher on the Desktop when available (otherwise in the user's
home directory).
It requires the receiver's local Codex config to use:

```toml
base_url = "https://www.chedankj.com"
```

If the local Codex config does not match, bootstrap stops and tells the user to
check the official install guide.

`npm run agent` listens for Weixin messages, sends each text prompt to Codex,
and replies to the same Weixin peer. The bridge stores Codex thread ids in
`.state/weixin-state.json`, so later messages from the same peer resume the
same Codex conversation instead of creating a separate record each time.

Use `npm run start` to run the agent as a detached background process. Logs are
written to `.state/agent.log` and the pid is stored in `.state/agent.pid`.
The bridge only works while that agent process is running. A machine reboot
stops it, so start it again with `npm run start` or by double-clicking the
launcher created on the Desktop or in the user's home directory. The current
package does not register itself as an auto-start system service.

On Windows, the runtime now requests hidden child processes for the background
agent and Codex invocations. Under normal use, sending a WeChat message should
not open a new command prompt window each time.

When connected through WeChat, the bridge defaults to open runtime settings:
`sandbox=danger-full-access`, `approval=never`, `search=on`, and progress
messages enabled. This keeps local tools such as Python image scripts from
getting blocked by sandbox setup issues before they even start, and lets Codex
use live search by default. A per-conversation `/settings` override still wins;
use `/settings reset` to return an existing conversation to these defaults.

## WeChat commands

The user gets a welcome message on first contact and can use:

- `/help` show commands
- `/skills [keyword]` list installed Codex skills visible to the bridge
- `/interrupt` stop the current Codex run for this WeChat peer
- `/settings` show the current conversation's sandbox, approval, search, and model
- `/settings sandbox <mode>` set sandbox for the current conversation
- `/settings approval <policy>` set approval policy for the current conversation
- `/settings search on|off` toggle web search for the current conversation
- `/settings model <name|default>` set model for the current conversation
- `/settings reset` reset the current conversation back to runtime defaults
- `/status` show current directory, Codex thread, progress setting, and run state
- `/cwd <dir>` switch the Codex working directory for this WeChat peer
- `/new` start a fresh Codex thread
- `/chat list` sync and list all local Codex sessions across directories
- `/chat sync` manually import local Codex sessions into the WeChat conversation list
- `/chat new [name]` create and switch to a conversation
- `/chat use <number|name|threadId>` switch conversation and restore its working directory
- `/chat rename <name>` rename current conversation
- `/chat current` show current conversation
- `/attach list` show recent files in the WeChat file workspace
- `/attach clear` clear recent attachment references without deleting files
- `/compact` start a fresh thread with a short continuity seed
- `/progress on|off` toggle intermediate status messages
- `/sendfile <path> [caption]` send a server file to the current WeChat peer

While one message is still running, the bridge keeps at most one queued follow-up
message for that WeChat peer. If the user sends another message before the run
finishes, the newest queued message replaces the older queued one. `/interrupt`
stops the active run and, if a queued message exists, immediately continues with it.

## Codex skill

Run `npm run install-skill` once on the host. It installs the bundled
`weixin-codex` skill into `~/.codex/skills/weixin-codex`. The bridge prefixes
every WeChat turn with `$weixin-codex`, so Codex understands WeChat constraints,
file delivery, and bridge commands without manual user configuration.

## Inbound attachments

When a WeChat user sends an image or file, the agent downloads and saves it
under `weixin-files/` in the active Codex working directory. The directory is
created only after the first inbound file arrives. Filenames include the source,
kind, any same-message text, and receive time so Codex can infer what the user
means by "这个图片" or "刚才那个文件".

The bridge maintains two helper files inside `weixin-files/`:

- `README.md` gives Codex a concise human-readable view of recent files.
- `files.json` records paths, original names, receive time, modify time, size,
  MIME type, and whether the file still exists.

The index refreshes when a message arrives, after Codex finishes a task, and
periodically while the agent is running. By default the periodic refresh interval
is 60 seconds; override it with `WEIXIN_CODEX_FILE_REFRESH_MS` or
`--file-refresh-interval <ms>`. The refresh also scans `weixin-files/`, so files
that Codex creates or modifies in that directory appear in the same index. When
Codex creates outputs related to inbound WeChat files, prefer writing them back
to `weixin-files/` so later messages can refer to them naturally.
Recent image paths may also be attached to `codex exec` with `--image` for image
understanding.

## Packaging

To build a distributable archive:

```bash
npm run package-release
```

The archive is written under `dist/` and includes:

- runtime source
- install scripts
- bundled `weixin-codex` skill
- `INSTALL.md`
- `INSTALL_WITH_CODEX.md`
- `ASK_CODEX_TO_INSTALL.txt`
