# qq-codex

独立的 QQ-Codex 本地桥接器，使用 QQ 开放平台 Bot API 连接 QQ。

它和微信桥接器分开运行，目录、状态文件、文件工作区都独立：

- 状态：`.state/qq-state.json`
- 日志：`.state/agent.log`
- QQ 附件目录：`qq-files/`
- skill：`qq-codex`

## 默认能力

- 私聊和群聊文本收发
- 图片和文件落盘到 `qq-files/`
- 图片消息发送：`send-image`，不会把 PNG/JPEG 当文件卡片发
- 文件发送：`send-file`
- `/help`、`/status`、`/settings`、`/cwd`、`/new`、`/chat`、`/attach`
- 默认运行状态：`sandbox=danger-full-access`、`approval=never`、`search=on`、进度消息=on

## 前置连接

先在 QQ 开放平台创建或启用机器人，拿到：

- `appId`
- `clientSecret`

```bash
export QQ_BOT_APP_ID='<appId>'
export QQ_BOT_CLIENT_SECRET='<clientSecret>'
```

Windows 用：

```bat
set QQ_BOT_APP_ID=<appId>
set QQ_BOT_CLIENT_SECRET=<clientSecret>
```

机器人需要开通群聊/C2C 消息事件权限。群聊里需要 @ 机器人触发，官方事件里使用的是 `user_openid`、`member_openid`、`group_openid`，不是 QQ 号或群号。

## 安装

```bash
npm install
npm run bootstrap
npm run start
```

然后在 QQ 私聊或群里发送 `/help`。

## 常用命令

```bash
npm run status
npm run stop
npm run start
npm run send -- --user-openid '<user_openid>' --text 'hello'
npm run send -- --group-openid '<group_openid>' --text 'hello'
npm run send-image -- --user-openid '<user_openid>' --file ./image.png
npm run send-file -- --group-openid '<group_openid>' --file ./report.pdf
npm run package-release
```

电脑重启后需要重新启动本桥接器后台服务，并确保 `QQ_BOT_APP_ID`、`QQ_BOT_CLIENT_SECRET` 仍然可用。
