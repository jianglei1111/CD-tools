# QQ Open Platform Bot

qq-codex uses the QQ Open Platform Bot API.

## Credentials

Set these before starting the bridge:

```bash
export QQ_BOT_APP_ID='<appId>'
export QQ_BOT_CLIENT_SECRET='<clientSecret>'
```

Windows:

```bat
set QQ_BOT_APP_ID=<appId>
set QQ_BOT_CLIENT_SECRET=<clientSecret>
```

## Protocol Summary

- Access token: `POST https://bots.qq.com/app/getAppAccessToken` with `{ appId, clientSecret }`
- API base: `https://api.sgroup.qq.com`
- Auth header: `Authorization: QQBot <access_token>`
- Gateway URL: `GET /gateway`
- Gateway intent: `GROUP_AND_C2C_EVENT` (`1 << 25`)
- Inbound events: `C2C_MESSAGE_CREATE`, `GROUP_AT_MESSAGE_CREATE`
- Text send: `POST /v2/users/{user_openid}/messages` or `/v2/groups/{group_openid}/messages`
- Media upload: `POST /v2/users/{user_openid}/files` or `/v2/groups/{group_openid}/files`
- Media send: message body with `msg_type: 7` and `media.file_info`

`user_openid`, `member_openid`, and `group_openid` are Open Platform IDs. They are not QQ numbers or QQ group numbers.
