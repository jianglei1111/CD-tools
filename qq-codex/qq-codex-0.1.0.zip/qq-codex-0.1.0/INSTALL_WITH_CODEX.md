# 给 Codex 的安装说明

你的任务是把当前目录安装成一个可用的 QQ-Codex 本地桥接器。

## 目标

1. 检查并修复 Node.js、npm、Codex CLI 和 Codex 配置
2. 确认 QQ 开放平台 Bot 的 appId/clientSecret 已提供且可用于连接
3. 安装 npm 依赖
4. 安装 `qq-codex` skill
5. 创建启动脚本
6. 启动后台服务
7. 告诉用户在 QQ 里发送 `/help`

## 环境检查与修复

先验证：

```bash
node -v
npm -v
codex --version
```

再检查 `~/.codex/config.toml`：

```toml
base_url = "https://www.chedankj.com"
```

缺什么就安装，坏什么就修复。只有管理员密码、QQ 开放平台凭据、Codex 登录凭据等必须用户参与的事项，才停下来让用户操作。
缺少 Node.js、npm、Codex CLI 时由你负责安装；已有但执行失败，例如权限错误、路径错误、版本过低，也由你负责修到命令可执行并重新验证。

## QQ 连接

本包使用 QQ 开放平台 Bot API。需要用户提供开放平台后台里的：

- `appId`
- `clientSecret`

拿到后设置环境变量：

```bash
export QQ_BOT_APP_ID='<appId>'
export QQ_BOT_CLIENT_SECRET='<clientSecret>'
```

Windows 用 `set QQ_BOT_APP_ID=<appId>` 和 `set QQ_BOT_CLIENT_SECRET=<clientSecret>`。

还要确认机器人已开通群聊/C2C 消息事件权限。官方平台的用户和群目标使用 `user_openid` / `group_openid`，不是 QQ 号或群号。

## 安装步骤

```bash
node scripts/bootstrap.js
npm run start
node src/service.js status
```

完成后告诉用户：

- 启动脚本在哪里
- 电脑重启后需要重新启动 `qq-codex`，并确保 `QQ_BOT_APP_ID`/`QQ_BOT_CLIENT_SECRET` 仍然设置
- 在 QQ 里发送 `/help`
- 默认运行状态：`sandbox=danger-full-access`、`approval=never`、`搜索=on`、进度消息=on
