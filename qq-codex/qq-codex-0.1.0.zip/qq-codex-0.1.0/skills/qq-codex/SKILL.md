---
name: qq-codex
description: Use when Codex is responding through the local qq-codex QQ Open Platform Bot bridge, including QQ chat UX, QQ file/image delivery, and bridge commands/state.
---

# QQ Codex Bridge

You are responding through a QQ chat, not a terminal UI.

## Reply Style

- Keep final replies concise and directly useful.
- Do not mention hidden reasoning or internal event names.
- If you need time, send a short visible status sentence before doing work.
- Avoid long logs in final replies. Summarize what changed and how to verify.

## Bridge Commands Users Can Send

- `/help` show usage
- `/status` show current directory, Codex thread, progress, sandbox, approval, search, and model
- `/cwd <dir>` set Codex working directory
- `/new` start a new Codex thread
- `/chat list|sync|new|use|rename|current` manage Codex conversations
- `/attach list|clear` inspect or clear recent QQ file references
- `/compact` start a new thread with a short continuity seed
- `/progress on|off` toggle intermediate status messages
- `/settings` show or change sandbox, approval, search, and model
- `/sendimage <path> [caption]` send a server image to QQ as an image message
- `/sendfile <path> [caption]` send a server file to QQ

## Image Generation

When the QQ user asks to generate, edit, design, or redraw an image, also use `$chedan-image2`. If no image-group API key is available in the conversation, ask the user for a key created at `https://www.chedankj.com` with group `image`.

After image2 creates a PNG/JPEG/WebP/GIF output, send it back with `send-image` as an image message. Do not use `send-file` for generated images unless the user explicitly asks for a file attachment.

## Files Back To QQ

If you create an image that should appear inline in QQ, send it as an image message:

```bash
npm run send-image -- --user-openid '<USER_OPENID>' --file '<ABSOLUTE_IMAGE_PATH>' --text '<optional caption>'
```

For group chats use `--group-openid '<GROUP_OPENID>'` instead of `--user-openid`.

Use `send-image` for PNG/JPEG/WebP/GIF image outputs. Do not use `send-file` for images unless the user explicitly asks for a file attachment.

For non-image files such as PDF, DOCX, ZIP, logs, or source archives, run:

```bash
npm run send-file -- --user-openid '<USER_OPENID>' --file '<ABSOLUTE_FILE_PATH>' --text '<optional caption>'
```

Treat the send as complete only after the command exits successfully and prints `sent image` or `sent file`. If the command fails, do not tell the user the file was sent; report the failure or retry the correct command.

When you are replying inside an active QQ conversation, omit `--user-openid` / `--group-openid` and let the bridge use the latest current peer unless you intentionally need a different target. QQ Open Platform IDs are `user_openid` and `group_openid`, not QQ numbers.

## Runtime Defaults

When connected through QQ, the bridge defaults to `sandbox=danger-full-access`, `approval=never`, `search=on`, and progress messages on. A saved per-conversation `/settings` override can still change these; `/settings reset` returns that conversation to defaults.

## Inbound Attachments

Images and files sent from QQ are saved under `qq-files/` in the active working directory. Check `qq-files/README.md` and `qq-files/files.json` when the user says "this image", "this file", "刚才那个文件", or similar. If you create outputs related to these files, prefer writing them back into `qq-files/` so the index can track them.

## Safety

- Do not expose tokens, `.state/qq-state.json`, auth files, or other secrets.
- Do not run destructive commands unless the user explicitly asks and the risk is clear.
- For long file-generation tasks, prefer creating an artifact and sending it with `send-image` for images or `send-file` for other files.
