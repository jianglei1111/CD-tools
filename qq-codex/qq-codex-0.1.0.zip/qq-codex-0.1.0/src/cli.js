import process from "node:process";

import {
  handleBridgeCommand,
  isBridgeCommand,
  sendWelcomeMessages,
} from "./commands.js";
import { CodexAbortError, CodexRunError, runCodex } from "./codex-runner.js";
import {
  fileWorkspacePrompt,
  recentImagePaths,
  refreshFileWorkspace,
  saveInboundAttachments,
} from "./inbound-media.js";
import { QQBotClient } from "./qqbot-client.js";
import {
  addPeerAttachments,
  clearCodexThreadId,
  getActivePeerChat,
  getCodexThreadId,
  getLatestPeer,
  getPeerAttachments,
  getPeerSettings,
  hasWelcomedPeer,
  loadState,
  markLatestPeer,
  markWelcomedPeer,
  resolveStatePath,
  setCodexThreadId,
  updatePeerChatById,
  updatePeerSettings,
} from "./state.js";
import { resolveDefaultSandbox } from "./runtime-defaults.js";

const command = process.argv[2] || "help";
const args = parseArgs(process.argv.slice(3));
const runtimeDefaults = {
  model: args.model || process.env.CODEX_BRIDGE_MODEL || "",
  sandbox: resolveDefaultSandbox(args.sandbox || process.env.CODEX_BRIDGE_SANDBOX),
  approval: args.approval || process.env.CODEX_BRIDGE_APPROVAL || "never",
  search: resolveSearchDefault(),
};
const peerRuns = new Map();
const account = { accountId: "qqbot" };

try {
  if (command === "agent") {
    await agent();
  } else if (command === "status") {
    status();
  } else if (command === "send") {
    await send();
  } else if (command === "send-file") {
    await sendFile();
  } else if (command === "send-image") {
    await sendImage();
  } else {
    help();
  }
} catch (err) {
  console.error(err.stack || err.message || String(err));
  process.exitCode = 1;
}

function status() {
  const state = loadState();
  console.log(`state: ${resolveStatePath()}`);
  console.log(`latestPeer: ${getLatestPeer(account.accountId) || "(none)"}`);
  console.log(`qqbot appId: ${maskSecret(args["app-id"] || process.env.QQ_BOT_APP_ID || process.env.QQBOT_APP_ID || "") || "(missing)"}`);
  console.log(`qqbot api: ${args["api-base"] || process.env.QQ_BOT_API_BASE || "https://api.sgroup.qq.com"}`);
  const chats = Object.keys(state.peerChats?.[account.accountId] || {});
  console.log(`peers: ${chats.length}`);
}

async function agent() {
  const defaultCwd = args.cwd || process.env.CODEX_BRIDGE_WORKDIR || process.cwd();
  const client = createClient();
  console.log(`qq agent connecting appId=${maskSecret(client.appId)}`);
  console.log(`codex workdir=${defaultCwd}`);
  const refreshTimer = startFileWorkspaceRefresh(defaultCwd);
  const keepAliveTimer = setInterval(() => {}, 60 * 60 * 1000);

  client.onMessage((message) => {
    handleIncomingMessage(client, message, defaultCwd).catch((err) => {
      console.error(`message handling failed: ${err.stack || err.message || String(err)}`);
    });
  });
  await client.connect();
  console.log("qq agent connected");

  const stop = async () => {
    clearInterval(refreshTimer);
    clearInterval(keepAliveTimer);
    await client.close().catch(() => {});
  };
  process.once("SIGINT", async () => {
    console.log("\nstopping...");
    await stop();
    process.exit(0);
  });
  process.once("SIGTERM", async () => {
    await stop();
    process.exit(0);
  });

  await new Promise(() => {});
}

async function handleIncomingMessage(client, message, defaultCwd) {
  const from = message.from;
  const text = message.text.trim();
  markLatestPeer(account.accountId, from);
  const settings = getPeerSettings(account.accountId, from);
  const codexCwd = args.cwd || settings.cwd || defaultCwd;
  const runState = getPeerRunState(account.accountId, from);
  const activeChat = getActivePeerChat(account.accountId, from);

  await refreshFileWorkspace(codexCwd).catch((err) => {
    console.error(`file workspace refresh failed: ${err.message || String(err)}`);
  });

  let savedAttachments = [];
  try {
    savedAttachments = await saveInboundAttachments(message, { cwd: codexCwd, text });
  } catch (err) {
    await replyLong(client, message.target, `附件保存失败：${err.message || String(err)}`);
    return;
  }
  if (savedAttachments.length) {
    addPeerAttachments(account.accountId, from, savedAttachments);
    console.log(`saved attachments from=${from} files=${savedAttachments.map((item) => item.path).join(",")}`);
  }
  if (!text && savedAttachments.length) {
    await replyLong(client, message.target, attachmentReceiptText(savedAttachments));
    return;
  }
  if (!text) return;

  console.log(`inbound from=${from} text=${JSON.stringify(text)}`);
  const commandHandled = isBridgeCommand(text) && await handleBridgeCommand(text, {
    account,
    from,
    defaultCwd,
    reply: (body) => replyBody(client, message.target, body),
    sendFile: (filePath, caption) => sendFileToTarget(client, message.target, filePath, caption),
    sendImage: (filePath, caption) => sendImageToTarget(client, message.target, filePath, caption),
    runtimeDefaults,
    getRunStatus: () => describeRunState(runState),
    interruptRun: () => interruptPeerRun(runState),
  });
  if (commandHandled) return;

  if (!hasWelcomedPeer(account.accountId, from)) {
    await sendWelcomeMessages((body) => replyBody(client, message.target, body));
    markWelcomedPeer(account.accountId, from);
  }

  const turn = createPendingTurn({
    target: message.target,
    from,
    text,
    savedAttachments,
    defaultCwd,
    codexCwd,
    settings,
    activeChat,
  });

  if (runState.busy || runState.draining) {
    const enqueueResult = enqueuePendingTurn(runState, turn);
    await replyLong(
      client,
      message.target,
      enqueueResult === "queued"
        ? "上一条还在处理，这条我先记下了。处理完会继续；发送 /interrupt 可立即中断。"
        : enqueueResult === "merged"
          ? "上一条还在处理，我已把你刚才的新消息并进排队内容。"
          : "上一条还在处理，我已用最新消息替换排队内容。",
    );
    return;
  }

  startPeerDrain(client, runState, turn);
}

function getPeerRunState(accountId, from) {
  const key = `${accountId}::${from}`;
  if (!peerRuns.has(key)) {
    peerRuns.set(key, {
      busy: false,
      draining: false,
      controller: null,
      queuedTurn: null,
      currentTurn: null,
    });
  }
  return peerRuns.get(key);
}

function describeRunState(runState) {
  return {
    busy: Boolean(runState?.busy),
    queued: Boolean(runState?.queuedTurn),
    queueLength: runState?.queuedTurn ? 1 : 0,
  };
}

async function interruptPeerRun(runState) {
  if (!runState?.busy || !runState.controller || runState.controller.signal.aborted) {
    return false;
  }
  runState.controller.abort();
  return true;
}

function createPendingTurn({ target, from, text, savedAttachments, defaultCwd, codexCwd, settings, activeChat }) {
  const recentAttachments = getPeerAttachments(account.accountId, from);
  const promptAttachments = selectPromptAttachments({
    text,
    currentAttachments: savedAttachments,
    recentAttachments,
  });
  const runConfig = resolveTurnRunConfig(activeChat);
  return {
    target,
    from,
    text,
    settings,
    defaultCwd,
    codexCwd,
    promptAttachments,
    runConfig,
    activeChatId: activeChat.id,
    activeChatTitle: activeChat.title,
    compactSeed: activeChat.compactSeed || "",
  };
}

function resolveTurnRunConfig(activeChat) {
  const chatConfig = activeChat?.runConfig || {};
  return {
    model: chatConfig.model || runtimeDefaults.model || "",
    sandbox: chatConfig.sandbox || runtimeDefaults.sandbox || resolveDefaultSandbox(),
    approval: chatConfig.approval || runtimeDefaults.approval || "never",
    search: chatConfig.search ?? runtimeDefaults.search ?? true,
  };
}

function startPeerDrain(client, runState, firstTurn) {
  runState.queuedTurn = firstTurn;
  if (runState.draining) return;
  runState.draining = true;
  drainPeerTurns(client, runState).catch((err) => {
    console.error(`peer drain failed: ${err.stack || err.message || String(err)}`);
  }).finally(() => {
    runState.draining = false;
  });
}

async function drainPeerTurns(client, runState) {
  while (runState.queuedTurn) {
    const turn = runState.queuedTurn;
    runState.queuedTurn = null;
    await processTurn(client, runState, turn);
  }
}

async function processTurn(client, runState, turn) {
  const { target, from, text, settings, codexCwd, promptAttachments, runConfig, activeChatId, compactSeed } = turn;
  runState.busy = true;
  runState.currentTurn = turn;
  runState.controller = new AbortController();

  try {
    await replyLong(client, target, turn.combinedTurns ? `收到，正在处理合并后的 ${turn.combinedTurns} 条消息...` : "收到，正在处理...");
    const prompt = buildCodexPrompt(text, from, {
      ...settings,
      cwd: codexCwd,
      attachments: promptAttachments,
      compactSeed,
    });
    const threadId = getCodexThreadId(account.accountId, from, activeChatId);
    let boundThreadId = threadId;
    const progressReporter = createQQProgressReporter(client, target, settings);
    const result = await runCodex(prompt, {
      threadId,
      cwd: codexCwd,
      model: runConfig.model,
      sandbox: runConfig.sandbox,
      approval: runConfig.approval,
      search: runConfig.search,
      timeoutMs: args["codex-timeout"],
      images: recentImagePaths(promptAttachments),
      onEvent: (event) => {
        if (event.type === "thread.started" && typeof event.thread_id === "string" && event.thread_id !== boundThreadId) {
          boundThreadId = event.thread_id;
          setCodexThreadId(account.accountId, from, event.thread_id, codexCwd, activeChatId);
          console.log(`bound codex thread peer=${from} chat=${activeChatId} thread=${event.thread_id}`);
        }
        progressReporter?.(event);
      },
      signal: runState.controller.signal,
    });
    if (result.threadId && result.threadId !== boundThreadId) {
      setCodexThreadId(account.accountId, from, result.threadId, codexCwd, activeChatId);
    }
    if (compactSeed) {
      updatePeerChatById(account.accountId, from, activeChatId, { compactSeed: undefined });
    }
    await replyLong(client, target, result.text);
  } catch (err) {
    if (err instanceof CodexAbortError) {
      await replyLong(client, target, runState.queuedTurn ? "已中断当前处理，接下来会继续处理你后面的消息。" : "已中断当前处理。你可以继续发新消息。");
    } else {
      console.error(err.details || err.stack || err.message || String(err));
      await replyLong(client, target, formatCodexFailureForQQ(err));
    }
  } finally {
    await refreshFileWorkspace(codexCwd).catch((err) => {
      console.error(`file workspace refresh failed: ${err.message || String(err)}`);
    });
    runState.busy = false;
    runState.currentTurn = null;
    runState.controller = null;
  }
}

function startFileWorkspaceRefresh(defaultCwd) {
  const configured = Number(args["file-refresh-interval"] || process.env.QQ_CODEX_FILE_REFRESH_MS);
  const intervalMs = Number.isFinite(configured) && configured > 0 ? configured : 60000;
  const timer = setInterval(() => {
    refreshFileWorkspace(defaultCwd).catch((err) => {
      console.error(`file workspace periodic refresh failed: ${err.message || String(err)}`);
    });
  }, Math.max(intervalMs, 5000));
  timer.unref?.();
  return timer;
}

function attachmentReceiptText(attachments) {
  const kinds = new Set((attachments || []).map((item) => item.kind));
  if (kinds.size === 1 && kinds.has("image")) return "已收到图片";
  if (kinds.size === 1 && kinds.has("video")) return "已收到视频";
  if (kinds.size === 1 && kinds.has("voice")) return "已收到语音";
  if (kinds.size === 1 && kinds.has("file")) return "已收到文件";
  return "已收到附件";
}

function selectPromptAttachments({ text, currentAttachments = [], recentAttachments = [] }) {
  if (currentAttachments.length) return currentAttachments;
  if (messageMentionsAttachment(text)) return recentAttachments;
  return [];
}

function messageMentionsAttachment(text) {
  const normalized = String(text || "").trim().toLowerCase();
  if (!normalized) return false;
  return [
    "这个文件",
    "那个文件",
    "刚才那个文件",
    "这个图片",
    "那张图片",
    "这张图片",
    "刚才那张图",
    "这个附件",
    "刚才的附件",
    "this file",
    "that file",
    "this image",
    "that image",
    "this attachment",
    "last file",
    "last image",
  ].some((needle) => normalized.includes(needle));
}

function enqueuePendingTurn(runState, turn) {
  const existing = runState.queuedTurn;
  if (!existing) {
    runState.queuedTurn = turn;
    return "queued";
  }
  if (existing.activeChatId === turn.activeChatId && existing.codexCwd === turn.codexCwd) {
    runState.queuedTurn = {
      ...turn,
      text: mergeTurnText(existing.text, turn.text),
      compactSeed: existing.compactSeed || turn.compactSeed || "",
      combinedTurns: (existing.combinedTurns || 1) + 1,
      promptAttachments: mergeTurnAttachments(existing.promptAttachments, turn.promptAttachments),
    };
    return "merged";
  }
  runState.queuedTurn = turn;
  return "replaced";
}

function mergeTurnText(existingText, incomingText) {
  const first = String(existingText || "").trim();
  const second = String(incomingText || "").trim();
  if (!first) return second;
  if (!second) return first;
  return `${first}\n\n[用户补充消息]\n${second}`;
}

function mergeTurnAttachments(existing = [], incoming = []) {
  const seen = new Set();
  const merged = [];
  for (const item of [...existing, ...incoming]) {
    const key = item?.path || item?.sourceUrl || item?.originalName || JSON.stringify(item);
    if (seen.has(key)) continue;
    seen.add(key);
    merged.push(item);
  }
  return merged;
}

function formatCodexFailureForQQ(err) {
  if (err instanceof CodexRunError && err.message) return err.message;
  return `Codex 执行失败：${err?.message || String(err)}`;
}

async function send() {
  const client = createClient();
  const target = parseTargetArgs();
  const text = args.text;
  if (!text) throw new Error("send requires --text '<message>'");
  await client.sendText(target, text);
  await client.close();
  console.log("sent");
}

async function sendFile() {
  const client = createClient();
  const target = parseTargetArgs();
  if (!args.file) throw new Error("send-file requires --file '<path>'");
  await client.sendFile(target, args.file, args.text || "");
  await client.close();
  console.log("sent file");
}

async function sendImage() {
  const client = createClient();
  const target = parseTargetArgs();
  if (!args.file) throw new Error("send-image requires --file '<path>'");
  await client.sendImage(target, args.file, args.text || "");
  await client.close();
  console.log("sent image");
}

function parseTargetArgs() {
  if (args["group-openid"]) return { chatType: "group", id: String(args["group-openid"]) };
  if (args.group) return { chatType: "group", id: String(args.group) };
  if (args["user-openid"]) return { chatType: "private", id: String(args["user-openid"]) };
  if (args.user) return { chatType: "private", id: String(args.user) };
  const latest = getLatestPeer(account.accountId);
  if (latest) {
    const [chatType, id] = latest.split(":");
    if ((chatType === "group" || chatType === "private") && id) return { chatType, id };
  }
  throw new Error("target required: --user-openid <openid> or --group-openid <group_openid>");
}

async function sendFileToTarget(client, target, filePath, text = "") {
  return client.sendFile(target, filePath, text);
}

async function sendImageToTarget(client, target, filePath, text = "") {
  return client.sendImage(target, filePath, text);
}

async function replyBody(client, target, body) {
  if (Array.isArray(body)) {
    for (const item of body) await replyLong(client, target, item);
    return;
  }
  return replyLong(client, target, body);
}

async function replyLong(client, target, text) {
  const chunks = chunkText(String(text || ""), 1800);
  for (const chunk of chunks) {
    await client.sendText(target, chunk);
  }
}

function buildCodexPrompt(text, from, settings = {}) {
  const requestedSkills = ["$qq-codex"];
  if (looksLikeImage2Request(text)) {
    requestedSkills.push("$chedan-image2");
  }
  return [
    requestedSkills.join("\n"),
    "你正在通过 QQ 为用户提供 Codex 助手服务。",
    "请直接回答用户消息。若需要修改代码，可以在当前仓库执行必要命令。",
    "如果用户要求生成图片、修图、画 logo/海报/头像/插画/素材，使用 $chedan-image2。若当前对话没有 image 组 API key，先让用户提供在 https://www.chedankj.com 创建的 image 组 key。",
    "如果需要把生成的图片发给当前 QQ 用户/群，用图片消息发送：npm run send-image -- --file '<图片路径>' --text '<可选说明>'。默认发给当前最近会话；指定目标时用 --user-openid 或 --group-openid。其他文件才用 send-file。",
    "只有在发送命令成功返回 sent image/sent file 后，才能告诉用户已经发送；失败时说明失败原因。",
    "最终回复会原样发回 QQ，所以保持简洁、可读，不要包含不必要的运行日志。",
    `QQ会话: ${from}`,
    `当前工作目录: ${settings.cwd || process.cwd()}`,
    fileWorkspacePrompt(settings.cwd || process.cwd(), settings.attachments || []),
    settings.compactSeed ? `上下文提示: ${settings.compactSeed}` : "",
    "",
    "用户消息:",
    text,
  ].filter(Boolean).join("\n");
}

function looksLikeImage2Request(text) {
  const value = String(text || "").toLowerCase();
  if (!value.trim()) return false;
  return [
    "生成图片",
    "生成一张",
    "画一张",
    "做一张图",
    "做张图",
    "出一张图",
    "修图",
    "改图",
    "p图",
    "图片生成",
    "生成海报",
    "做海报",
    "设计海报",
    "logo",
    "头像",
    "插画",
    "封面",
    "表情包",
    "壁纸",
    "image2",
    "generate image",
    "make an image",
    "create an image",
    "draw",
    "poster",
  ].some((needle) => value.includes(needle));
}

function createQQProgressReporter(client, target, settings = {}) {
  if (args.progress === "false" || process.env.QQ_CODEX_PROGRESS === "0") return undefined;
  if (settings.progress === false) return undefined;
  let lastSentAt = 0;
  let pendingAgentMessage;
  const minIntervalMs = Number(args["progress-interval"] || process.env.QQ_CODEX_PROGRESS_INTERVAL_MS || 6000);

  return (event) => {
    if (event.type === "item.completed" && event.item?.type === "agent_message" && event.item?.text) {
      pendingAgentMessage = shortenOneLine(event.item.text, 100);
      return;
    }
    if (event.type === "turn.completed") {
      pendingAgentMessage = undefined;
      return;
    }
    const toolLine = summarizeToolProgressEvent(event);
    if (toolLine && pendingAgentMessage) {
      replyLong(client, target, pendingAgentMessage).catch((err) => console.error(`progress send failed: ${err.message || String(err)}`));
      pendingAgentMessage = undefined;
      return;
    }
    const now = Date.now();
    const immediate = event.type === "thread.started" || event.type === "turn.started";
    if (!immediate && now - lastSentAt < minIntervalMs) return;
    lastSentAt = now;
  };
}

function summarizeToolProgressEvent(event) {
  const item = event.item || {};
  if (event.type !== "item.started" && event.type !== "item.completed") return undefined;
  if (item.type === "command_execution") return "tool";
  if (item.type === "file_change") return "tool";
  if (item.type === "web_search") return "tool";
  return undefined;
}

function resolveSearchDefault() {
  if (args.search === true || args.search === "true" || args.search === "1") return true;
  if (args.search === false || args.search === "false" || args.search === "0") return false;
  const envValue = String(process.env.CODEX_BRIDGE_SEARCH || "").trim().toLowerCase();
  if (envValue === "0" || envValue === "false" || envValue === "off" || envValue === "disabled") return false;
  return true;
}

function chunkText(text, maxLen) {
  const normalized = String(text || "");
  if (normalized.length <= maxLen) return [normalized];
  const chunks = [];
  for (let index = 0; index < normalized.length; index += maxLen) {
    chunks.push(normalized.slice(index, index + maxLen));
  }
  return chunks;
}

function shortenOneLine(value, maxLen) {
  const line = String(value).replace(/\s+/g, " ").trim();
  if (line.length <= maxLen) return line;
  return `${line.slice(0, maxLen - 1)}…`;
}

function help() {
  console.log(`Usage:
  npm run agent -- [--cwd <dir>] [--app-id <id>] [--client-secret <secret>]
  npm run status
  npm run send -- --user-openid <openid> --text <message>
  npm run send -- --group-openid <group_openid> --text <message>
  npm run send-image -- --user-openid <openid> --file <path> [--text <caption>]
  npm run send-file -- --group-openid <group_openid> --file <path> [--text <caption>]
  npm run start
  npm run stop
`);
}

function createClient() {
  return new QQBotClient({
    appId: args["app-id"],
    clientSecret: args["client-secret"],
    apiBase: args["api-base"],
    intents: args.intents,
  });
}

function maskSecret(value) {
  const text = String(value || "");
  if (!text) return "";
  if (text.length <= 6) return `${text[0] || ""}***`;
  return `${text.slice(0, 3)}***${text.slice(-3)}`;
}

function parseArgs(raw) {
  const parsed = {};
  for (let i = 0; i < raw.length; i += 1) {
    const part = raw[i];
    if (!part.startsWith("--")) continue;
    const key = part.slice(2);
    const next = raw[i + 1];
    if (!next || next.startsWith("--")) {
      parsed[key] = true;
    } else {
      parsed[key] = next;
      i += 1;
    }
  }
  return parsed;
}
