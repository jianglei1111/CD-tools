import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import WebSocket from "ws";

const TOKEN_URL = "https://bots.qq.com/app/getAppAccessToken";
const DEFAULT_API_BASE = "https://api.sgroup.qq.com";
const DEFAULT_TIMEOUT_MS = 30000;
const DEFAULT_UPLOAD_TIMEOUT_MS = 120000;
const DEFAULT_INTENTS = 1 << 25; // GROUP_AND_C2C_EVENT
const DEFAULT_TOKEN_EXPIRES_IN_SECONDS = 7200;

const GatewayOp = {
  DISPATCH: 0,
  HEARTBEAT: 1,
  IDENTIFY: 2,
  RESUME: 6,
  RECONNECT: 7,
  INVALID_SESSION: 9,
  HELLO: 10,
  HEARTBEAT_ACK: 11,
};

const GatewayEvent = {
  READY: "READY",
  RESUMED: "RESUMED",
  C2C_MESSAGE_CREATE: "C2C_MESSAGE_CREATE",
  GROUP_AT_MESSAGE_CREATE: "GROUP_AT_MESSAGE_CREATE",
};

const MediaFileType = {
  image: 1,
  video: 2,
  voice: 3,
  file: 4,
};

const MediaSizeLimit = {
  image: 30 * 1024 * 1024,
  video: 100 * 1024 * 1024,
  voice: 20 * 1024 * 1024,
  file: 100 * 1024 * 1024,
};

export class QQBotClient {
  constructor(options = {}) {
    this.appId = String(options.appId || process.env.QQ_BOT_APP_ID || process.env.QQBOT_APP_ID || "").trim();
    this.clientSecret = String(options.clientSecret || process.env.QQ_BOT_CLIENT_SECRET || process.env.QQBOT_CLIENT_SECRET || "").trim();
    this.apiBase = stripTrailingSlash(options.apiBase || process.env.QQ_BOT_API_BASE || DEFAULT_API_BASE);
    this.timeoutMs = Number(options.timeoutMs || process.env.QQ_BOT_TIMEOUT_MS || DEFAULT_TIMEOUT_MS);
    this.uploadTimeoutMs = Number(options.uploadTimeoutMs || process.env.QQ_BOT_UPLOAD_TIMEOUT_MS || DEFAULT_UPLOAD_TIMEOUT_MS);
    this.intents = Number(options.intents || process.env.QQ_BOT_INTENTS || DEFAULT_INTENTS);
    this.userAgent = options.userAgent || `qq-codex/0.1.0 node/${process.versions.node}`;
    this.ws = undefined;
    this.messageHandler = undefined;
    this.connectedAt = 0;
    this.lastSeq = null;
    this.sessionId = "";
    this.heartbeatTimer = undefined;
    this.ready = false;
    this.pendingReady = undefined;
    this.reconnectTimer = undefined;
    this.manualClose = false;
    this.tokenCache = undefined;
  }

  async connect() {
    this.ensureCredentials();
    if (this.ws?.readyState === WebSocket.OPEN && this.ready) return;

    const accessToken = await this.getAccessToken();
    const gatewayUrl = await this.getGatewayUrl(accessToken);
    this.manualClose = false;
    this.ready = false;

    const ws = new WebSocket(gatewayUrl, {
      headers: { "User-Agent": this.userAgent },
    });
    this.ws = ws;

    ws.on("message", (data) => {
      this.handleGatewayMessage(data, accessToken).catch((err) => {
        console.error(`QQBot gateway message failed: ${err.stack || err.message || String(err)}`);
      });
    });
    ws.on("close", (code, reason) => this.handleClose(code, reason));
    ws.on("error", (err) => {
      this.rejectReady(err);
      console.error(`QQBot gateway error: ${err.message || String(err)}`);
    });

    await this.waitUntilReady(gatewayUrl);
  }

  onMessage(handler) {
    this.messageHandler = handler;
  }

  async close() {
    this.manualClose = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = undefined;
    }
    this.clearHeartbeat();
    const ws = this.ws;
    this.ws = undefined;
    if (!ws) return;
    if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
      ws.close();
    }
  }

  async sendText(target, text) {
    const msgId = targetMessageId(target);
    const body = msgId
      ? { content: text, msg_type: 0, msg_seq: nextMsgSeq(msgId), msg_id: msgId }
      : { content: text, msg_type: 0 };
    return this.apiRequest("POST", messagePath(target), body);
  }

  async sendImage(target, filePath, caption = "") {
    return this.sendMedia(target, filePath, "image", caption);
  }

  async sendFile(target, filePath, caption = "") {
    if (caption) {
      await this.sendText(target, caption);
    }
    return this.sendMedia(target, filePath, "file");
  }

  async sendMedia(target, filePath, kind, content = "") {
    const resolved = path.resolve(filePath);
    const buffer = await fs.readFile(resolved);
    const maxBytes = MediaSizeLimit[kind] || MediaSizeLimit.file;
    if (buffer.length > maxBytes) {
      throw new Error(`${kind} is too large for QQBot upload: ${buffer.length} bytes`);
    }

    const uploadBody = {
      file_type: MediaFileType[kind] || MediaFileType.file,
      srv_send_msg: false,
      file_data: buffer.toString("base64"),
    };
    if (kind === "file") {
      uploadBody.file_name = sanitizeFileName(path.basename(resolved));
    }

    const upload = await this.apiRequest("POST", mediaUploadPath(target), uploadBody, {
      timeoutMs: this.uploadTimeoutMs,
    });
    if (!upload?.file_info) {
      throw new Error(`QQBot media upload did not return file_info: ${JSON.stringify(upload)}`);
    }

    const msgId = targetMessageId(target);
    const body = {
      msg_type: 7,
      media: { file_info: upload.file_info },
      msg_seq: msgId ? nextMsgSeq(msgId) : 1,
      ...(content ? { content } : {}),
      ...(msgId ? { msg_id: msgId } : {}),
    };
    return this.apiRequest("POST", messagePath(target), body, {
      timeoutMs: this.uploadTimeoutMs,
    });
  }

  async getGatewayUrl(accessToken) {
    const data = await this.apiRequest("GET", "/gateway", undefined, { accessToken });
    if (!data?.url) {
      throw new Error(`QQBot gateway response has no url: ${JSON.stringify(data)}`);
    }
    return data.url;
  }

  async getAccessToken(force = false) {
    this.ensureCredentials();
    const cached = this.tokenCache;
    if (!force && cached && Date.now() < cached.expiresAt - 5 * 60 * 1000) {
      return cached.token;
    }

    const res = await fetch(TOKEN_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": this.userAgent,
      },
      body: JSON.stringify({
        appId: this.appId,
        clientSecret: this.clientSecret,
      }),
    });
    const raw = await res.text();
    let data;
    try {
      data = raw ? JSON.parse(raw) : {};
    } catch {
      throw new Error(`QQBot access_token response was not JSON: ${raw.slice(0, 160)}`);
    }
    if (!res.ok || !data.access_token) {
      throw new Error(`QQBot access_token failed: HTTP ${res.status} ${data.message || raw}`.trim());
    }
    const expiresIn = positiveNumber(data.expires_in) || DEFAULT_TOKEN_EXPIRES_IN_SECONDS;
    this.tokenCache = {
      token: data.access_token,
      expiresAt: Date.now() + expiresIn * 1000,
    };
    return data.access_token;
  }

  async apiRequest(method, requestPath, body, options = {}) {
    const accessToken = options.accessToken || await this.getAccessToken();
    const timeoutMs = Number(options.timeoutMs || this.timeoutMs);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    timeout.unref?.();

    let res;
    try {
      res = await fetch(`${this.apiBase}${requestPath}`, {
        method,
        headers: {
          Authorization: `QQBot ${accessToken}`,
          "Content-Type": "application/json",
          "User-Agent": this.userAgent,
        },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }),
        signal: controller.signal,
      });
    } catch (err) {
      if (err?.name === "AbortError") {
        throw new Error(`QQBot API timed out: ${method} ${requestPath}`);
      }
      throw err;
    } finally {
      clearTimeout(timeout);
    }

    const raw = await res.text();
    let data;
    try {
      data = raw ? JSON.parse(raw) : {};
    } catch {
      data = { raw };
    }

    if (res.status === 401 && !options.retriedAuth) {
      this.tokenCache = undefined;
      return this.apiRequest(method, requestPath, body, { ...options, accessToken: undefined, retriedAuth: true });
    }

    if (!res.ok) {
      const message = data?.message || data?.msg || data?.raw || raw || res.statusText;
      throw new Error(`QQBot API failed ${method} ${requestPath}: HTTP ${res.status} ${message}`.trim());
    }
    return data;
  }

  async waitUntilReady(gatewayUrl) {
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingReady = undefined;
        reject(new Error(`QQBot gateway ready timed out: ${gatewayUrl}`));
      }, this.timeoutMs);
      this.pendingReady = {
        resolve: () => {
          clearTimeout(timer);
          this.pendingReady = undefined;
          resolve();
        },
        reject: (err) => {
          clearTimeout(timer);
          this.pendingReady = undefined;
          reject(err);
        },
      };
    });
  }

  resolveReady() {
    this.ready = true;
    this.connectedAt = Date.now();
    this.pendingReady?.resolve();
  }

  rejectReady(err) {
    this.pendingReady?.reject(err instanceof Error ? err : new Error(String(err)));
  }

  async handleGatewayMessage(data, accessToken) {
    const payload = JSON.parse(decodeGatewayMessageData(data));
    if (typeof payload.s === "number") {
      this.lastSeq = payload.s;
    }

    if (payload.op === GatewayOp.HELLO) {
      this.handleHello(payload.d, accessToken);
      return;
    }

    if (payload.op === GatewayOp.DISPATCH) {
      if (payload.t === GatewayEvent.READY) {
        this.sessionId = payload.d?.session_id || "";
        this.resolveReady();
        return;
      }
      if (payload.t === GatewayEvent.RESUMED) {
        this.resolveReady();
        return;
      }
      if (payload.t === GatewayEvent.C2C_MESSAGE_CREATE || payload.t === GatewayEvent.GROUP_AT_MESSAGE_CREATE) {
        const message = normalizeMessage(payload.t, payload.d);
        if (message) {
          this.messageHandler?.(message);
        }
      }
      return;
    }

    if (payload.op === GatewayOp.HEARTBEAT) {
      this.sendHeartbeat();
      return;
    }

    if (payload.op === GatewayOp.RECONNECT) {
      this.scheduleReconnect(1000);
      this.ws?.close();
      return;
    }

    if (payload.op === GatewayOp.INVALID_SESSION) {
      if (!payload.d) {
        this.sessionId = "";
        this.lastSeq = null;
        this.tokenCache = undefined;
      }
      this.scheduleReconnect(3000);
      this.ws?.close();
    }
  }

  handleHello(data, accessToken) {
    if (this.sessionId && this.lastSeq !== null) {
      this.ws?.send(JSON.stringify({
        op: GatewayOp.RESUME,
        d: {
          token: `QQBot ${accessToken}`,
          session_id: this.sessionId,
          seq: this.lastSeq,
        },
      }));
    } else {
      this.ws?.send(JSON.stringify({
        op: GatewayOp.IDENTIFY,
        d: {
          token: `QQBot ${accessToken}`,
          intents: this.intents,
          shard: [0, 1],
        },
      }));
    }

    this.clearHeartbeat();
    const interval = positiveNumber(data?.heartbeat_interval) || 45000;
    this.heartbeatTimer = setInterval(() => this.sendHeartbeat(), interval);
    this.heartbeatTimer.unref?.();
  }

  sendHeartbeat() {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ op: GatewayOp.HEARTBEAT, d: this.lastSeq }));
    }
  }

  handleClose(code, reason) {
    this.ready = false;
    this.clearHeartbeat();
    console.error(`QQBot gateway closed: ${code} ${reason?.toString?.() || ""}`.trim());
    this.rejectReady(new Error(`QQBot gateway closed: ${code} ${reason?.toString?.() || ""}`.trim()));
    if (this.manualClose) return;
    if (code === 4004 || code === 4006 || code === 4007 || code === 4009) {
      this.sessionId = "";
      this.lastSeq = null;
      this.tokenCache = undefined;
    }
    if (code === 4914 || code === 4915) {
      console.error(`QQBot gateway fatal close: ${code}. Check bot event permissions/intents.`);
      return;
    }
    this.scheduleReconnect(code === 4008 ? 60000 : 3000);
  }

  scheduleReconnect(delayMs) {
    if (this.manualClose || this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = undefined;
      this.connect().catch((err) => {
        console.error(`QQBot reconnect failed: ${err.message || String(err)}`);
        this.scheduleReconnect(5000);
      });
    }, delayMs);
    this.reconnectTimer.unref?.();
  }

  clearHeartbeat() {
    if (!this.heartbeatTimer) return;
    clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = undefined;
  }

  ensureCredentials() {
    if (!this.appId || !this.clientSecret) {
      throw new Error("QQBot credentials missing: set QQ_BOT_APP_ID and QQ_BOT_CLIENT_SECRET");
    }
  }
}

export function normalizeMessage(eventType, event) {
  if (!event || typeof event !== "object") return undefined;

  if (eventType === GatewayEvent.C2C_MESSAGE_CREATE) {
    const senderId = String(event.author?.user_openid || event.user_openid || event.openid || "");
    if (!senderId) return undefined;
    const messageId = String(event.id || event.msg_id || `${Date.now()}-${senderId}`);
    const target = { chatType: "private", id: senderId, messageId, msgId: messageId };
    return {
      accountId: "qqbot",
      from: `private:${senderId}`,
      target,
      senderId,
      chatId: senderId,
      chatType: "private",
      messageId,
      text: normalizeContent(event),
      attachments: extractAttachments(event),
      raw: event,
    };
  }

  if (eventType === GatewayEvent.GROUP_AT_MESSAGE_CREATE) {
    const groupId = String(event.group_openid || event.group_id || "");
    const senderId = String(event.author?.member_openid || event.author?.user_openid || event.member_openid || "");
    if (!groupId) return undefined;
    const messageId = String(event.id || event.msg_id || `${Date.now()}-${senderId || groupId}`);
    const target = { chatType: "group", id: groupId, messageId, msgId: messageId };
    return {
      accountId: "qqbot",
      from: `group:${groupId}`,
      target,
      senderId,
      chatId: groupId,
      chatType: "group",
      messageId,
      text: stripQQMentions(normalizeContent(event), event.mentions),
      attachments: extractAttachments(event),
      raw: event,
    };
  }

  return undefined;
}

export async function downloadAttachment(attachment, options = {}) {
  const maxBytes = Number(options.maxBytes || process.env.QQ_CODEX_MAX_INBOUND_BYTES || 100 * 1024 * 1024);
  const url = normalizeAttachmentUrl(attachment.url);
  if (!url) {
    throw new Error(`QQ attachment has no URL: ${attachment.name || attachment.kind}`);
  }
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`QQ attachment download failed: ${res.status} ${res.statusText}`);
  }
  const buffer = Buffer.from(await res.arrayBuffer());
  if (buffer.length > maxBytes) {
    throw new Error(`附件太大：${attachment.name || attachment.kind} (${buffer.length} bytes)`);
  }
  return {
    kind: attachment.kind,
    fileName: attachment.name || defaultAttachmentName(attachment.kind, res.headers.get("content-type")),
    mimeType: res.headers.get("content-type") || mimeFromName(attachment.name),
    buffer,
  };
}

export async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

function normalizeContent(event) {
  const parts = [];
  if (typeof event.content === "string") {
    parts.push(event.content);
  }
  for (const element of event.msg_elements || []) {
    if (typeof element?.content === "string" && element.content.trim()) {
      parts.push(element.content);
    }
  }
  return parts.join("\n").trim();
}

function stripQQMentions(text, mentions = []) {
  let result = String(text || "");
  const targetMentions = Array.isArray(mentions) && mentions.some((item) => item?.is_you)
    ? mentions.filter((item) => item?.is_you)
    : mentions;
  for (const mention of targetMentions || []) {
    for (const id of [mention.member_openid, mention.user_openid, mention.id].filter(Boolean)) {
      result = result.replace(new RegExp(`<@!?${escapeRegex(String(id))}>`, "g"), "");
    }
  }
  return result.replace(/<@!?[^>]+>/g, "").replace(/\s+/g, " ").trim();
}

function extractAttachments(event) {
  const result = [];
  for (const attachment of event.attachments || []) {
    result.push(normalizeAttachment(attachment));
  }
  for (const element of event.msg_elements || []) {
    for (const attachment of element?.attachments || []) {
      result.push(normalizeAttachment(attachment));
    }
  }
  return result.filter((item) => item.url);
}

function normalizeAttachment(attachment) {
  const contentType = String(attachment.content_type || "").toLowerCase();
  const url = normalizeAttachmentUrl(attachment.url);
  const fileName = attachment.filename || path.basename(String(url || "qq-file.bin")).split("?")[0] || "qq-file.bin";
  return {
    kind: kindFromContentType(contentType, attachment),
    name: fileName,
    url,
    mimeType: contentType || mimeFromName(fileName),
    raw: attachment,
  };
}

function kindFromContentType(contentType, attachment) {
  if (contentType.startsWith("image/")) return "image";
  if (contentType.startsWith("video/")) return "video";
  if (contentType.startsWith("audio/") || attachment.voice_wav_url || attachment.asr_refer_text) return "voice";
  return "file";
}

function messagePath(target) {
  const id = encodeURIComponent(String(target.id));
  return target.chatType === "group" ? `/v2/groups/${id}/messages` : `/v2/users/${id}/messages`;
}

function mediaUploadPath(target) {
  const id = encodeURIComponent(String(target.id));
  return target.chatType === "group" ? `/v2/groups/${id}/files` : `/v2/users/${id}/files`;
}

function targetMessageId(target) {
  return String(target.msgId || target.messageId || "").trim();
}

function nextMsgSeq(msgId) {
  const timePart = Date.now() % 100000000;
  const random = Math.floor(Math.random() * 65536);
  return (timePart ^ random ^ hashSmall(msgId)) % 65536;
}

function hashSmall(value) {
  let hash = 0;
  for (const ch of String(value || "")) {
    hash = ((hash << 5) - hash + ch.charCodeAt(0)) | 0;
  }
  return Math.abs(hash);
}

function decodeGatewayMessageData(data) {
  if (typeof data === "string") return data;
  if (Buffer.isBuffer(data)) return data.toString("utf8");
  if (Array.isArray(data) && data.every((chunk) => Buffer.isBuffer(chunk))) {
    return Buffer.concat(data).toString("utf8");
  }
  if (data instanceof ArrayBuffer) return Buffer.from(data).toString("utf8");
  if (ArrayBuffer.isView(data)) return Buffer.from(data.buffer, data.byteOffset, data.byteLength).toString("utf8");
  return "";
}

function normalizeAttachmentUrl(url) {
  const value = String(url || "").trim();
  if (!value) return "";
  if (value.startsWith("//")) return `https:${value}`;
  return value;
}

function defaultAttachmentName(kind, contentType) {
  if (kind === "image") return `qq-image${extensionFromMime(contentType) || ".jpg"}`;
  if (kind === "video") return "qq-video.mp4";
  if (kind === "voice") return "qq-voice.silk";
  return "qq-file.bin";
}

function extensionFromMime(mime) {
  if (!mime) return "";
  if (mime.includes("png")) return ".png";
  if (mime.includes("jpeg") || mime.includes("jpg")) return ".jpg";
  if (mime.includes("gif")) return ".gif";
  if (mime.includes("webp")) return ".webp";
  if (mime.includes("mp4")) return ".mp4";
  return "";
}

function mimeFromName(name = "") {
  const ext = path.extname(name).toLowerCase();
  if (ext === ".png") return "image/png";
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".gif") return "image/gif";
  if (ext === ".webp") return "image/webp";
  if (ext === ".mp4") return "video/mp4";
  if (ext === ".pdf") return "application/pdf";
  if (ext === ".zip") return "application/zip";
  return "application/octet-stream";
}

function sanitizeFileName(name) {
  return String(name || "qq-file.bin").replace(/[\\/:*?"<>|]/g, "_").slice(0, 120) || "qq-file.bin";
}

function stripTrailingSlash(value) {
  return String(value || "").replace(/\/+$/, "");
}

function positiveNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : 0;
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
