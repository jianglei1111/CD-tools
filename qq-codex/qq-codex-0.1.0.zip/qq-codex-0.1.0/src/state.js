import fs from "node:fs";
import path from "node:path";

const DEFAULT_STATE_DIR = path.resolve(".state");
const STATE_FILE = "qq-state.json";

export function resolveStateDir() {
  return path.resolve(process.env.QQ_CODEX_STATE_DIR || DEFAULT_STATE_DIR);
}

export function resolveStatePath() {
  return path.join(resolveStateDir(), STATE_FILE);
}

export function loadState() {
  const filePath = resolveStatePath();
  try {
    if (!fs.existsSync(filePath)) {
      return emptyState();
    }
    const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
    return {
      ...emptyState(),
      ...parsed,
      accounts: parsed.accounts && typeof parsed.accounts === "object" ? parsed.accounts : {},
      sync: parsed.sync && typeof parsed.sync === "object" ? parsed.sync : {},
      contextTokens:
        parsed.contextTokens && typeof parsed.contextTokens === "object"
          ? parsed.contextTokens
          : {},
      peerSettings:
        parsed.peerSettings && typeof parsed.peerSettings === "object"
          ? parsed.peerSettings
          : {},
      peerChats:
        parsed.peerChats && typeof parsed.peerChats === "object"
          ? parsed.peerChats
          : {},
      peerAttachments:
        parsed.peerAttachments && typeof parsed.peerAttachments === "object"
          ? parsed.peerAttachments
          : {},
      welcomedPeers:
        parsed.welcomedPeers && typeof parsed.welcomedPeers === "object"
          ? parsed.welcomedPeers
          : {},
    };
  } catch (err) {
    throw new Error(`failed to load state: ${err.message}`);
  }
}

export function saveState(state) {
  const dir = resolveStateDir();
  fs.mkdirSync(dir, { recursive: true });
  const filePath = resolveStatePath();
  fs.writeFileSync(filePath, `${JSON.stringify(state, null, 2)}\n`, "utf8");
  try {
    fs.chmodSync(filePath, 0o600);
  } catch {
    // Best effort on filesystems that support POSIX modes.
  }
}

export function saveAccount(account) {
  const state = loadState();
  state.accounts[account.accountId] = {
    ...state.accounts[account.accountId],
    ...account,
    savedAt: new Date().toISOString(),
  };
  state.latestAccountId = account.accountId;
  saveState(state);
}

export function getAccount(accountId) {
  const state = loadState();
  const id = accountId || state.latestAccountId;
  if (!id) {
    throw new Error("no QQ peer has been seen yet; start the agent and send a QQ message first");
  }
  const account = state.accounts[id];
  if (!account?.token) {
    throw new Error(`account ${id} has no saved token`);
  }
  return account;
}

export function listRecentTokens(limit = 10) {
  const state = loadState();
  return Object.values(state.accounts)
    .sort((a, b) => String(b.savedAt || "").localeCompare(String(a.savedAt || "")))
    .map((account) => account.token)
    .filter((token) => typeof token === "string" && token.trim())
    .slice(0, limit);
}

export function getSyncBuf(accountId) {
  const state = loadState();
  return state.sync[accountId]?.getUpdatesBuf || "";
}

export function setSyncBuf(accountId, getUpdatesBuf) {
  const state = loadState();
  state.sync[accountId] = { getUpdatesBuf, updatedAt: new Date().toISOString() };
  saveState(state);
}

export function setContextToken(accountId, userId, contextToken) {
  if (!accountId || !userId || !contextToken) return;
  const state = loadState();
  state.contextTokens[accountId] ||= {};
  state.contextTokens[accountId][userId] = contextToken;
  state.latestPeerByAccount ||= {};
  state.latestPeerByAccount[accountId] = userId;
  saveState(state);
}

export function markLatestPeer(accountId, userId) {
  if (!accountId || !userId) return;
  const state = loadState();
  state.latestPeerByAccount ||= {};
  state.latestPeerByAccount[accountId] = userId;
  saveState(state);
}

export function getContextToken(accountId, userId) {
  const state = loadState();
  return state.contextTokens[accountId]?.[userId];
}

export function getLatestPeer(accountId) {
  const state = loadState();
  const direct = state.latestPeerByAccount?.[accountId];
  if (direct) return direct;
  const peers = Object.keys(state.contextTokens[accountId] || {});
  return peers[peers.length - 1];
}

export function getCodexThreadId(accountId, userId, chatId) {
  const state = loadState();
  const chat = chatId
    ? getChatByIdFromState(state, accountId, userId, chatId)
    : getActiveChatFromState(state, accountId, userId);
  return chat?.threadId;
}

export function setCodexThreadId(accountId, userId, threadId, cwd, chatId) {
  if (!accountId || !userId || !threadId) return;
  const state = loadState();
  const chat = chatId
    ? ensureChatById(state, accountId, userId, chatId)
    : ensureActiveChat(state, accountId, userId);
  chat.threadId = threadId;
  if (cwd) chat.cwd = cwd;
  chat.updatedAt = new Date().toISOString();
  if (getPeerChatBucket(state, accountId, userId).activeChatId === chat.id) {
    state.codexThreads ||= {};
    state.codexThreads[accountId] ||= {};
    state.codexThreads[accountId][userId] = threadId;
  }
  saveState(state);
}

export function clearCodexThreadId(accountId, userId) {
  const state = loadState();
  const chat = ensureActiveChat(state, accountId, userId);
  delete chat.threadId;
  chat.updatedAt = new Date().toISOString();
  if (state.codexThreads?.[accountId]) {
    delete state.codexThreads[accountId][userId];
  }
  saveState(state);
}

export function listPeerChats(accountId, userId) {
  const state = loadState();
  ensureActiveChat(state, accountId, userId);
  saveState(state);
  return getPeerChatBucket(state, accountId, userId).chats;
}

export function getActivePeerChat(accountId, userId) {
  const state = loadState();
  const chat = ensureActiveChat(state, accountId, userId);
  saveState(state);
  return chat;
}

export function createPeerChat(accountId, userId, title, options = {}) {
  const state = loadState();
  const bucket = getPeerChatBucket(state, accountId, userId);
  const chat = {
    id: `chat-${Date.now().toString(36)}-${Math.random().toString(16).slice(2, 8)}`,
    title: title?.trim() || `对话 ${bucket.chats.length + 1}`,
    ...(options.cwd ? { cwd: options.cwd } : {}),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  bucket.chats.push(chat);
  bucket.activeChatId = chat.id;
  saveState(state);
  return chat;
}

export function updateActivePeerChat(accountId, userId, patch) {
  const state = loadState();
  const chat = ensureActiveChat(state, accountId, userId);
  Object.assign(chat, patch, { updatedAt: new Date().toISOString() });
  saveState(state);
  return chat;
}

export function updatePeerChatById(accountId, userId, chatId, patch) {
  const state = loadState();
  const chat = ensureChatById(state, accountId, userId, chatId);
  Object.assign(chat, patch, { updatedAt: new Date().toISOString() });
  saveState(state);
  return chat;
}

export function upsertPeerChatFromThread(accountId, userId, threadId, title, options = {}) {
  const state = loadState();
  const bucket = getPeerChatBucket(state, accountId, userId);
  let chat = bucket.chats.find((item) => item.threadId === threadId);
  if (!chat) {
    chat = {
      id: `chat-${Date.now().toString(36)}-${Math.random().toString(16).slice(2, 8)}`,
      title: title?.trim() || `Codex ${threadId.slice(0, 8)}`,
      threadId,
      imported: true,
      ...(options.cwd ? { cwd: options.cwd } : {}),
      ...(options.sourcePath ? { sourcePath: options.sourcePath } : {}),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    bucket.chats.push(chat);
  } else {
    let changed = false;
    if (title?.trim() && (chat.title.startsWith("Codex ") || chat.title === "Codex 会话")) {
      chat.title = title.trim();
      changed = true;
    }
    if (options.cwd && chat.cwd !== options.cwd) {
      chat.cwd = options.cwd;
      changed = true;
    }
    if (options.sourcePath && chat.sourcePath !== options.sourcePath) {
      chat.sourcePath = options.sourcePath;
      changed = true;
    }
    if (changed) chat.updatedAt = new Date().toISOString();
  }
  if (!bucket.activeChatId) bucket.activeChatId = chat.id;
  saveState(state);
  return chat;
}

export function switchPeerChat(accountId, userId, selector) {
  const state = loadState();
  const bucket = getPeerChatBucket(state, accountId, userId);
  ensureActiveChat(state, accountId, userId);
  const raw = String(selector || "").trim();
  const index = Number(raw);
  const chat = Number.isInteger(index) && index >= 1
    ? bucket.chats[index - 1]
    : bucket.chats.find((item) =>
        item.id === raw ||
        item.threadId === raw ||
        item.id?.startsWith(raw) ||
        item.threadId?.startsWith(raw) ||
        item.title === raw
      );
  if (!chat) return undefined;
  bucket.activeChatId = chat.id;
  saveState(state);
  return chat;
}

export function renameActivePeerChat(accountId, userId, title) {
  const state = loadState();
  const chat = ensureActiveChat(state, accountId, userId);
  chat.title = title.trim();
  chat.updatedAt = new Date().toISOString();
  saveState(state);
  return chat;
}

export function getPeerSettings(accountId, userId) {
  const state = loadState();
  return state.peerSettings?.[accountId]?.[userId] || {};
}

export function updatePeerSettings(accountId, userId, patch) {
  const state = loadState();
  state.peerSettings ||= {};
  state.peerSettings[accountId] ||= {};
  state.peerSettings[accountId][userId] = {
    ...(state.peerSettings[accountId][userId] || {}),
    ...patch,
    updatedAt: new Date().toISOString(),
  };
  saveState(state);
  return state.peerSettings[accountId][userId];
}

export function addPeerAttachments(accountId, userId, attachments, limit = 10) {
  if (!accountId || !userId || !attachments?.length) return [];
  const state = loadState();
  state.peerAttachments ||= {};
  state.peerAttachments[accountId] ||= {};
  const existing = Array.isArray(state.peerAttachments[accountId][userId])
    ? state.peerAttachments[accountId][userId]
    : [];
  state.peerAttachments[accountId][userId] = [...attachments, ...existing].slice(0, limit);
  saveState(state);
  return state.peerAttachments[accountId][userId];
}

export function getPeerAttachments(accountId, userId, limit = 5) {
  const state = loadState();
  const attachments = state.peerAttachments?.[accountId]?.[userId];
  return Array.isArray(attachments) ? attachments.slice(0, limit) : [];
}

export function clearPeerAttachments(accountId, userId) {
  const state = loadState();
  if (state.peerAttachments?.[accountId]) {
    state.peerAttachments[accountId][userId] = [];
    saveState(state);
  }
}

export function hasWelcomedPeer(accountId, userId) {
  const state = loadState();
  return Boolean(state.welcomedPeers?.[accountId]?.[userId]);
}

export function markWelcomedPeer(accountId, userId) {
  const state = loadState();
  state.welcomedPeers ||= {};
  state.welcomedPeers[accountId] ||= {};
  state.welcomedPeers[accountId][userId] = new Date().toISOString();
  saveState(state);
}

function emptyState() {
  return {
    latestAccountId: undefined,
    accounts: {},
    sync: {},
    contextTokens: {},
    latestPeerByAccount: {},
    codexThreads: {},
    peerChats: {},
    peerAttachments: {},
    peerSettings: {},
    welcomedPeers: {},
  };
}

function getPeerChatBucket(state, accountId, userId) {
  state.peerChats ||= {};
  state.peerChats[accountId] ||= {};
  state.peerChats[accountId][userId] ||= { activeChatId: undefined, chats: [] };
  return state.peerChats[accountId][userId];
}

function getActiveChatFromState(state, accountId, userId) {
  const bucket = state.peerChats?.[accountId]?.[userId];
  if (!bucket?.activeChatId) return undefined;
  return bucket.chats?.find((chat) => chat.id === bucket.activeChatId);
}

function getChatByIdFromState(state, accountId, userId, chatId) {
  const bucket = state.peerChats?.[accountId]?.[userId];
  return bucket?.chats?.find((chat) => chat.id === chatId);
}

function ensureActiveChat(state, accountId, userId) {
  const bucket = getPeerChatBucket(state, accountId, userId);
  let chat = bucket.chats.find((item) => item.id === bucket.activeChatId);
  if (!chat) {
    const legacyThreadId = state.codexThreads?.[accountId]?.[userId];
    chat = {
      id: `chat-${Date.now().toString(36)}-${Math.random().toString(16).slice(2, 8)}`,
      title: "默认对话",
      ...(legacyThreadId ? { threadId: legacyThreadId } : {}),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    bucket.chats.push(chat);
    bucket.activeChatId = chat.id;
  }
  return chat;
}

function ensureChatById(state, accountId, userId, chatId) {
  const existing = getChatByIdFromState(state, accountId, userId, chatId);
  return existing || ensureActiveChat(state, accountId, userId);
}
