import process from "node:process";

export function resolveDefaultSandbox(configuredValue, platform = process.platform) {
  const explicit = String(configuredValue || "").trim();
  if (explicit) return explicit;
  return "danger-full-access";
}

export function isWindowsSandboxStartupFailure(message) {
  const text = String(message || "").toLowerCase();
  return text.includes("windows sandbox") && text.includes("spawn setup refresh");
}
