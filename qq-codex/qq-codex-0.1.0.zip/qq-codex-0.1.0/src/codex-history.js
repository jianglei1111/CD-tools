import fs from "node:fs";
import path from "node:path";

export function listCodexHistory(limit = Infinity) {
  const historyBySession = readHistoryIndex();
  const sessionsById = new Map();

  for (const filePath of listSessionFiles()) {
    const session = readSessionSummary(filePath);
    if (!session?.threadId) continue;

    const history = historyBySession.get(session.threadId);
    sessionsById.set(session.threadId, {
      threadId: session.threadId,
      title: history?.title || session.title || `Codex ${session.threadId.slice(0, 8)}`,
      firstText: history?.firstText || session.firstText || "",
      firstTs: minKnown(history?.firstTs, session.firstTs),
      lastTs: Math.max(history?.lastTs || 0, session.lastTs || 0),
      count: history?.count || 0,
      cwd: session.cwd,
      sourcePath: filePath,
    });
  }

  for (const history of historyBySession.values()) {
    if (sessionsById.has(history.threadId)) continue;
    sessionsById.set(history.threadId, history);
  }

  return [...sessionsById.values()]
    .sort((a, b) => (b.lastTs || 0) - (a.lastTs || 0))
    .slice(0, limit);
}

function readHistoryIndex() {
  const filePath = resolveHistoryPath();
  if (!fs.existsSync(filePath)) return new Map();

  const bySession = new Map();
  const lines = fs.readFileSync(filePath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    if (!line.trim()) continue;
    try {
      const item = JSON.parse(line);
      if (!item.session_id) continue;
      const existing = bySession.get(item.session_id);
      const ts = Number(item.ts || 0);
      if (!existing) {
        bySession.set(item.session_id, {
          threadId: item.session_id,
          title: titleFromText(item.text),
          firstText: item.text || "",
          firstTs: ts,
          lastTs: ts,
          count: 1,
        });
      } else {
        existing.lastTs = Math.max(existing.lastTs, ts);
        existing.count += 1;
      }
    } catch {
      // Ignore malformed history lines.
    }
  }

  return bySession;
}

function resolveHistoryPath() {
  const codexHome = process.env.CODEX_HOME || path.join(process.env.HOME || "", ".codex");
  return path.join(codexHome, "history.jsonl");
}

function resolveSessionsDir() {
  const codexHome = process.env.CODEX_HOME || path.join(process.env.HOME || "", ".codex");
  return path.join(codexHome, "sessions");
}

function listSessionFiles() {
  const root = resolveSessionsDir();
  const files = [];
  walkSessionDir(root, files);
  return files;
}

function walkSessionDir(dir, files) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walkSessionDir(fullPath, files);
    } else if (entry.isFile() && entry.name.endsWith(".jsonl")) {
      files.push(fullPath);
    }
  }
}

function readSessionSummary(filePath) {
  let stat;
  let lines;
  try {
    stat = fs.statSync(filePath);
    lines = fs.readFileSync(filePath, "utf8").split(/\r?\n/);
  } catch {
    return undefined;
  }

  const summary = {
    threadId: undefined,
    cwd: undefined,
    firstText: "",
    firstTs: Math.floor(stat.mtimeMs / 1000),
    lastTs: Math.floor(stat.mtimeMs / 1000),
  };

  for (const line of lines) {
    if (!line.trim()) continue;
    let item;
    try {
      item = JSON.parse(line);
    } catch {
      continue;
    }

    const ts = timestampToSeconds(item.timestamp || item.payload?.timestamp);
    if (ts) {
      summary.firstTs = Math.min(summary.firstTs || ts, ts);
      summary.lastTs = Math.max(summary.lastTs || ts, ts);
    }

    if (item.type === "session_meta") {
      summary.threadId = item.payload?.id || summary.threadId;
      summary.cwd = item.payload?.cwd || summary.cwd;
      continue;
    }

    if (item.type === "turn_context" && item.payload?.cwd) {
      summary.cwd = item.payload.cwd;
      continue;
    }

    if (!summary.firstText) {
      summary.firstText = extractUserText(item);
    }
  }

  return {
    ...summary,
    title: titleFromText(summary.firstText),
  };
}

function extractUserText(item) {
  const payload = item.payload || {};
  if (item.type === "event_msg" && payload.type === "user_message") {
    return cleanPromptText(payload.message);
  }
  if (item.type === "response_item" && payload.type === "message" && payload.role === "user") {
    return cleanPromptText(contentText(payload.content));
  }
  return "";
}

function contentText(content) {
  if (!Array.isArray(content)) return "";
  return content
    .map((part) => part?.text || "")
    .filter(Boolean)
    .join("\n");
}

function cleanPromptText(text) {
  const raw = String(text || "").trim();
  if (!raw || raw.startsWith("<environment_context>") || raw.startsWith("<skill>")) {
    return "";
  }

  const marker = "用户消息:";
  const markerIndex = raw.lastIndexOf(marker);
  if (markerIndex !== -1) {
    return raw.slice(markerIndex + marker.length).trim();
  }

  return raw;
}

function timestampToSeconds(value) {
  if (!value) return undefined;
  if (typeof value === "number") return value > 100000000000 ? Math.floor(value / 1000) : value;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? Math.floor(parsed / 1000) : undefined;
}

function minKnown(left, right) {
  if (!left) return right || 0;
  if (!right) return left;
  return Math.min(left, right);
}

function titleFromText(text) {
  const raw = String(text || "").replace(/\s+/g, " ").trim();
  if (!raw) return "Codex 会话";
  return raw.length > 28 ? `${raw.slice(0, 27)}...` : raw;
}
