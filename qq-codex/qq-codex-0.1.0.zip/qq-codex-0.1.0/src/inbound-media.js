import fs from "node:fs/promises";
import path from "node:path";

import { downloadAttachment } from "./qqbot-client.js";

const WORKSPACE_DIR = "qq-files";
const INDEX_FILE = "files.json";
const README_FILE = "README.md";

const MIME_BY_EXTENSION = {
  ".pdf": "application/pdf",
  ".doc": "application/msword",
  ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ".xls": "application/vnd.ms-excel",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ".ppt": "application/vnd.ms-powerpoint",
  ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  ".txt": "text/plain",
  ".csv": "text/csv",
  ".zip": "application/zip",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".mp4": "video/mp4",
  ".mov": "video/quicktime",
  ".mp3": "audio/mpeg",
  ".wav": "audio/wav",
};

export function resolveFileWorkspace(cwd = process.cwd()) {
  return path.join(path.resolve(cwd), WORKSPACE_DIR);
}

export async function saveInboundAttachments(message, options = {}) {
  const cwd = path.resolve(options.cwd || process.cwd());
  const workspaceDir = path.resolve(options.workspaceDir || resolveFileWorkspace(cwd));
  const saved = [];
  if (!message.attachments?.length) {
    await refreshFileWorkspace(cwd).catch(() => {});
    return saved;
  }

  await fs.mkdir(workspaceDir, { recursive: true });
  for (let index = 0; index < message.attachments.length; index += 1) {
    const attachment = message.attachments[index];
    const downloaded = await downloadAttachment(attachment, options);
    const filePath = await saveAttachmentBuffer(downloaded.buffer, {
      workspaceDir,
      message,
      index,
      fileName: downloaded.fileName,
      kind: downloaded.kind,
      text: options.text,
    });
    saved.push({
      kind: downloaded.kind,
      path: filePath,
      relativePath: path.relative(cwd, filePath),
      fileName: path.basename(filePath),
      originalName: downloaded.fileName,
      description: describeFile(downloaded.kind, downloaded.fileName, options.text),
      mimeType: downloaded.mimeType,
      size: downloaded.buffer.length,
      messageId: message.messageId || "",
      receivedAt: new Date().toISOString(),
    });
  }

  if (saved.length) {
    await appendWorkspaceIndex(cwd, saved);
  }
  return saved;
}

export async function refreshFileWorkspace(cwd = process.cwd()) {
  const root = path.resolve(cwd);
  const workspaceDir = resolveFileWorkspace(cwd);
  const workspaceExists = await pathExists(workspaceDir);
  let index = await readWorkspaceIndex(workspaceDir);
  if (!workspaceExists && !index.files.length) return index;

  const discovered = workspaceExists ? await discoverWorkspaceFiles(root, workspaceDir) : [];
  index = mergeWorkspaceEntries(root, workspaceDir, index, discovered);
  index = {
    ...index,
    updatedAt: new Date().toISOString(),
    refreshedAt: new Date().toISOString(),
    files: await Promise.all(index.files.map(async (entry) => refreshIndexEntry(entry))),
  };
  index.files.sort(compareWorkspaceEntries);
  index.files = index.files.slice(0, 300);
  await fs.mkdir(workspaceDir, { recursive: true });
  await fs.writeFile(path.join(workspaceDir, INDEX_FILE), `${JSON.stringify(index, null, 2)}\n`, "utf8");
  await writeWorkspaceReadme(workspaceDir, index);
  return index;
}

export async function listWorkspaceFiles(cwd = process.cwd(), limit = 10) {
  const index = await refreshFileWorkspace(cwd);
  return index.files.slice(0, limit);
}

export function formatAttachmentSummary(attachments) {
  if (!attachments?.length) return "";
  return attachments
    .map((item, index) => {
      const size = item.size ? ` ${formatBytes(item.size)}` : "";
      const marker = index === 0 ? "最新" : `${index + 1}`;
      const label = item.description || item.originalName || item.fileName || item.kind || "file";
      return `${marker}. ${label}\n   ${item.path}${size}`;
    })
    .join("\n");
}

export function recentImagePaths(attachments, limit = 3) {
  return (attachments || [])
    .filter((item) => item.kind === "image" && item.path)
    .map((item) => item.path)
    .slice(0, limit);
}

export function fileWorkspacePrompt(cwd = process.cwd(), attachments = []) {
  const workspaceDir = resolveFileWorkspace(cwd);
  const lines = [
    `QQ文件目录: ${workspaceDir}`,
    `索引文件: ${path.join(workspaceDir, INDEX_FILE)}`,
    `说明文件: ${path.join(workspaceDir, README_FILE)}`,
    "当用户说“这个图片/文件/刚发的文件”时，优先查看该目录的 README.md 和 files.json，再根据最近接收、文件名和修改时间判断目标。",
    "处理QQ文件产生的新文件，优先放回这个目录；刷新器会自动把目录内文件收录到 files.json。",
  ];
  if (attachments?.length) {
    lines.push("最近文件:");
    lines.push(formatAttachmentSummary(attachments));
  }
  return lines.join("\n");
}

async function appendWorkspaceIndex(cwd, entries) {
  const workspaceDir = resolveFileWorkspace(cwd);
  const index = await readWorkspaceIndex(workspaceDir);
  const discovered = await discoverWorkspaceFiles(path.resolve(cwd), workspaceDir);
  const merged = mergeWorkspaceEntries(cwd, workspaceDir, index, [...entries, ...discovered]);
  const next = {
    version: 1,
    workspaceDir,
    updatedAt: new Date().toISOString(),
    refreshedAt: new Date().toISOString(),
    files: (await Promise.all(merged.files.map(async (entry) => refreshIndexEntry(entry))))
      .sort(compareWorkspaceEntries)
      .slice(0, 300),
  };
  await fs.mkdir(workspaceDir, { recursive: true });
  await fs.writeFile(path.join(workspaceDir, INDEX_FILE), `${JSON.stringify(next, null, 2)}\n`, "utf8");
  await writeWorkspaceReadme(workspaceDir, next);
}

async function readWorkspaceIndex(workspaceDir) {
  try {
    const parsed = JSON.parse(await fs.readFile(path.join(workspaceDir, INDEX_FILE), "utf8"));
    return {
      version: 1,
      workspaceDir,
      updatedAt: parsed.updatedAt || new Date().toISOString(),
      refreshedAt: parsed.refreshedAt || parsed.updatedAt || new Date().toISOString(),
      files: Array.isArray(parsed.files) ? parsed.files : [],
    };
  } catch {
    return {
      version: 1,
      workspaceDir,
      updatedAt: new Date().toISOString(),
      refreshedAt: new Date().toISOString(),
      files: [],
    };
  }
}

async function refreshIndexEntry(entry) {
  const filePath = path.resolve(entry.path);
  try {
    const stat = await fs.stat(filePath);
    return {
      ...entry,
      path: filePath,
      exists: true,
      size: stat.size,
      modifiedAt: stat.mtime.toISOString(),
      refreshedAt: new Date().toISOString(),
    };
  } catch {
    return {
      ...entry,
      path: filePath,
      exists: false,
      refreshedAt: new Date().toISOString(),
    };
  }
}

async function discoverWorkspaceFiles(cwd, workspaceDir) {
  let dirents;
  try {
    dirents = await fs.readdir(workspaceDir, { withFileTypes: true });
  } catch {
    return [];
  }
  const now = new Date().toISOString();
  const result = [];
  for (const dirent of dirents) {
    if (!dirent.isFile() || dirent.name === INDEX_FILE || dirent.name === README_FILE) continue;
    const filePath = path.join(workspaceDir, dirent.name);
    let stat;
    try {
      stat = await fs.stat(filePath);
    } catch {
      continue;
    }
    if (!stat.isFile()) continue;
    const kind = inferKindFromFileName(dirent.name);
    result.push({
      kind,
      path: filePath,
      relativePath: path.relative(cwd, filePath),
      fileName: dirent.name,
      originalName: dirent.name,
      description: `QQ文件目录中的${kindLabel(kind)}：${dirent.name}`,
      mimeType: mimeFromFileName(dirent.name),
      size: stat.size,
      discoveredAt: now,
      modifiedAt: stat.mtime.toISOString(),
      exists: true,
    });
  }
  return result;
}

function mergeWorkspaceEntries(cwd, workspaceDir, index, entries) {
  const byPath = new Map();
  for (const entry of index.files || []) {
    const normalized = normalizeWorkspaceEntry(cwd, workspaceDir, entry);
    byPath.set(normalized.path, normalized);
  }
  for (const entry of entries || []) {
    const normalized = normalizeWorkspaceEntry(cwd, workspaceDir, entry);
    const previous = byPath.get(normalized.path);
    byPath.set(normalized.path, previous ? { ...normalized, ...previous, path: normalized.path } : normalized);
  }
  return {
    version: 1,
    workspaceDir,
    updatedAt: index.updatedAt || new Date().toISOString(),
    refreshedAt: index.refreshedAt || index.updatedAt || new Date().toISOString(),
    files: [...byPath.values()],
  };
}

function normalizeWorkspaceEntry(cwd, workspaceDir, entry) {
  const filePath = path.isAbsolute(entry.path || "")
    ? path.resolve(entry.path)
    : path.resolve(workspaceDir, entry.path || entry.fileName || "");
  return {
    ...entry,
    path: filePath,
    relativePath: entry.relativePath || path.relative(cwd, filePath),
    fileName: entry.fileName || path.basename(filePath),
    originalName: entry.originalName || entry.fileName || path.basename(filePath),
    mimeType: entry.mimeType || mimeFromFileName(filePath),
    kind: entry.kind || inferKindFromFileName(filePath),
  };
}

async function writeWorkspaceReadme(workspaceDir, index) {
  const lines = [
    "# QQ Files",
    "",
    "这个目录由 qq-codex 自动维护。",
    "QQ 用户发送的图片、文件、视频、语音会保存到这里。",
    "当用户说“这个图片”“刚才那个文件”“处理一下附件”时，优先看本文件和 files.json。",
    "处理这些文件产生的新文件也可以放在这里，刷新器会自动收录。",
    "",
    `更新时间: ${index.refreshedAt || index.updatedAt}`,
    "",
    "## 最近文件",
    "",
  ];
  if (!index.files.length) {
    lines.push("暂无文件。");
  } else {
    for (const [idx, item] of index.files.slice(0, 20).entries()) {
      const marker = idx === 0 ? "最新" : String(idx + 1);
      const size = item.size ? `, ${formatBytes(item.size)}` : "";
      const modified = item.modifiedAt ? `, modified ${item.modifiedAt}` : "";
      lines.push(`- ${marker}: ${item.description || item.originalName || item.fileName}`);
      lines.push(`  - path: ${item.path}`);
      lines.push(`  - kind: ${item.kind || "file"}${size}${modified}`);
      if (item.receivedAt) lines.push(`  - received: ${item.receivedAt}`);
      if (item.discoveredAt) lines.push(`  - discovered: ${item.discoveredAt}`);
      if (item.originalName && item.originalName !== item.fileName) lines.push(`  - original: ${item.originalName}`);
    }
  }
  lines.push("");
  await fs.writeFile(path.join(workspaceDir, README_FILE), `${lines.join("\n")}\n`, "utf8");
}

async function saveAttachmentBuffer(buffer, options) {
  const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\..+/, "").replace("T", "-");
  const filePath = path.join(options.workspaceDir, makeReadableFileName({
    kind: options.kind,
    originalName: options.fileName,
    text: options.text,
    stamp,
    messageId: options.message?.messageId,
    index: options.index,
  }));
  await fs.writeFile(filePath, buffer);
  return filePath;
}

function makeReadableFileName({ kind, originalName, text, stamp, messageId, index }) {
  const ext = path.extname(originalName || "") || defaultExtension(kind);
  const originalBase = path.basename(originalName || "", ext);
  const baseParts = [
    "qq",
    kind || "file",
    topicFromText(text) || safeSlug(originalBase) || "latest",
    stamp,
    shortId(messageId),
    index > 0 ? String(index + 1) : "",
  ].filter(Boolean);
  return `${baseParts.join("-")}${ext.toLowerCase()}`;
}

function topicFromText(text) {
  const raw = String(text || "").replace(/[/\\:*?"<>|]/g, " ").replace(/\s+/g, " ").trim();
  return raw ? safeSlug(raw).slice(0, 36) : "";
}

function describeFile(kind, originalName, text) {
  const userText = String(text || "").replace(/\s+/g, " ").trim();
  const label = kindLabel(kind);
  if (userText) return `QQ${label}，同条消息文字：${userText.slice(0, 60)}`;
  if (originalName) return `QQ${label}：${originalName}`;
  return `QQ${label}`;
}

function safeSlug(value) {
  return String(value || "")
    .replace(/\0/g, "")
    .normalize("NFKC")
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "";
}

function shortId(value) {
  return safeSlug(value).slice(0, 12);
}

function defaultExtension(kind) {
  if (kind === "image") return ".jpg";
  if (kind === "video") return ".mp4";
  if (kind === "voice") return ".silk";
  return ".bin";
}

function inferKindFromFileName(fileName) {
  const ext = path.extname(fileName || "").toLowerCase();
  if ([".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".heic"].includes(ext)) return "image";
  if ([".mp4", ".mov", ".avi", ".mkv", ".webm"].includes(ext)) return "video";
  if ([".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".silk"].includes(ext)) return "voice";
  return "file";
}

function kindLabel(kind) {
  if (kind === "image") return "图片";
  if (kind === "video") return "视频";
  if (kind === "voice") return "语音";
  return "文件";
}

function compareWorkspaceEntries(a, b) {
  return String(newestEntryTime(b)).localeCompare(String(newestEntryTime(a)));
}

function newestEntryTime(entry) {
  return [entry.modifiedAt, entry.receivedAt, entry.discoveredAt].filter(Boolean).sort().at(-1) || "";
}

function mimeFromFileName(fileName) {
  return MIME_BY_EXTENSION[path.extname(fileName).toLowerCase()] || "application/octet-stream";
}

function formatBytes(value) {
  const bytes = Number(value || 0);
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)}KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
}

async function pathExists(value) {
  try {
    await fs.access(value);
    return true;
  } catch {
    return false;
  }
}
