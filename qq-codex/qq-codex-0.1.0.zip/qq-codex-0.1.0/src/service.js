import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { resolveDefaultSandbox } from "./runtime-defaults.js";

const stateDir = path.resolve(".state");
const pidPath = path.join(stateDir, "agent.pid");
const logPath = path.join(stateDir, "agent.log");

const command = process.argv[2] || "status";
const passthroughArgs = process.argv.slice(3);

if (command === "start") {
  start();
} else if (command === "stop") {
  stop();
} else if (command === "status") {
  status();
} else {
  console.error("usage: node src/service.js start|stop|status");
  process.exitCode = 1;
}

function start() {
  fs.mkdirSync(stateDir, { recursive: true });
  const existing = readPid();
  if (existing && isAlive(existing)) {
    console.log(`agent already running pid=${existing}`);
    return;
  }

  const logFd = fs.openSync(logPath, "a");
  const childEnv = {
    ...process.env,
  };
  if (!childEnv.CODEX_BRIDGE_SANDBOX && !hasArgValue(passthroughArgs, "--sandbox")) {
    childEnv.CODEX_BRIDGE_SANDBOX = resolveDefaultSandbox("", process.platform);
  }
  const child = spawn(process.execPath, ["src/cli.js", "agent", ...passthroughArgs], {
    cwd: process.cwd(),
    env: childEnv,
    detached: true,
    stdio: ["ignore", logFd, logFd],
    windowsHide: true,
  });
  child.unref();
  fs.writeFileSync(pidPath, `${child.pid}\n`, "utf8");
  console.log(`agent started pid=${child.pid}`);
  console.log(`log=${logPath}`);
}

function stop() {
  const pid = readPid();
  if (!pid) {
    console.log("agent not running (no pid file)");
    return;
  }
  if (!isAlive(pid)) {
    fs.rmSync(pidPath, { force: true });
    console.log(`agent not running; removed stale pid=${pid}`);
    return;
  }
  process.kill(pid, "SIGTERM");
  fs.rmSync(pidPath, { force: true });
  console.log(`agent stopped pid=${pid}`);
}

function status() {
  const pid = readPid();
  if (pid && isAlive(pid)) {
    console.log(`agent running pid=${pid}`);
    console.log(`log=${logPath}`);
  } else {
    console.log("agent not running");
  }
}

function readPid() {
  try {
    const raw = fs.readFileSync(pidPath, "utf8").trim();
    const pid = Number(raw);
    return Number.isInteger(pid) && pid > 0 ? pid : undefined;
  } catch {
    return undefined;
  }
}

function isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

function hasArgValue(args, flag) {
  const index = args.indexOf(flag);
  return index >= 0 && index < args.length - 1;
}
