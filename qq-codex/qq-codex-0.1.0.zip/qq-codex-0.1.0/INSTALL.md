# 安装说明

这是独立的 QQ-Codex 桥接器，不和微信桥接器混在一起。

Codex 安装负责人需要把运行环境准备到可用：

- Node.js >= 18.17
- npm
- codex 命令可用
- 当前用户 `~/.codex/config.toml` 存在，且 `base_url = "https://www.chedankj.com"`
- QQ 开放平台 Bot 已创建/启用，并拿到 `appId`、`clientSecret`
- 机器人已开通群聊/C2C 消息事件权限

缺什么就装什么，已有但不能用就修到可用。修完必须重新验证。

## 安装步骤

```bash
node scripts/bootstrap.js
npm run start
node src/service.js status
```

启动前设置 QQ 开放平台凭据：

```bash
export QQ_BOT_APP_ID='<appId>'
export QQ_BOT_CLIENT_SECRET='<clientSecret>'
```

## 使用

在 QQ 私聊或群里发送：

```text
/help
```

默认运行状态：`sandbox=danger-full-access`、`approval=never`、`搜索=on`、进度消息=on。

如果旧对话有保存设置，发送 `/settings reset` 恢复默认。

说明：官方平台里的目标 ID 是 `user_openid` / `group_openid`，不是 QQ 号或群号。
