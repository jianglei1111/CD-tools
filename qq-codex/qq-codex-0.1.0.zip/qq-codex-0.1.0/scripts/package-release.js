import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, "..");
const packageJson = JSON.parse(fs.readFileSync(path.join(repoRoot, "package.json"), "utf8"));
const distDir = path.join(repoRoot, "dist");
const stageName = `qq-codex-${packageJson.version}`;
const stageDir = path.join(distDir, stageName);
const PYTHON_ZIP_SCRIPT = `
import shutil
import sys

source_dir = sys.argv[1]
zip_path = sys.argv[2]
base_name = zip_path[:-4] if zip_path.endswith(".zip") else zip_path
shutil.make_archive(base_name, "zip", root_dir=".", base_dir=source_dir)
`;
const includes = [
  ".gitignore",
  "ASK_CODEX_TO_INSTALL.txt",
  "INSTALL.md",
  "INSTALL_WITH_CODEX.md",
  "README.md",
  "package-lock.json",
  "package.json",
  "references",
  "scripts",
  "skills",
  "src",
];

fs.mkdirSync(distDir, { recursive: true });
fs.rmSync(stageDir, { recursive: true, force: true });

for (const entry of includes) {
  const source = path.join(repoRoot, entry);
  const target = path.join(stageDir, entry);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.cpSync(source, target, { recursive: true });
}

const zipPath = path.join(distDir, `${stageName}.zip`);
fs.rmSync(zipPath, { force: true });

if (hasCommand("zip")) {
  runArchive("zip", ["-qr", zipPath, stageName], distDir);
  console.log(`已生成压缩包：${zipPath}`);
} else if (hasCommand("python3")) {
  runArchive("python3", ["-c", PYTHON_ZIP_SCRIPT, stageName, zipPath], distDir);
  console.log(`未检测到 zip，已通过 python3 生成压缩包：${zipPath}`);
} else {
  console.error("未检测到 zip 或 python3，无法生成 zip 压缩包。");
  process.exit(1);
}

fs.rmSync(stageDir, { recursive: true, force: true });

function hasCommand(command) {
  const result = spawnSync("/bin/bash", ["-lc", `command -v ${command}`], {
    cwd: repoRoot,
    stdio: "ignore",
    windowsHide: true,
  });
  return result.status === 0;
}

function runArchive(command, args, cwd) {
  const result = spawnSync(command, args, {
    cwd,
    stdio: "inherit",
    env: process.env,
    windowsHide: true,
  });
  if (result.error) {
    throw result.error;
  }
  if (result.status !== 0) {
    process.exit(result.status || 1);
  }
}
