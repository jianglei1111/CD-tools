import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, "..");
const source = path.join(repoRoot, "skills", "qq-codex");
const codexHome = process.env.CODEX_HOME || path.join(process.env.HOME || "", ".codex");
const skillsRoot = path.join(codexHome, "skills");
const target = path.join(skillsRoot, "qq-codex");

fs.mkdirSync(skillsRoot, { recursive: true });
fs.rmSync(target, { recursive: true, force: true });
fs.cpSync(source, target, { recursive: true });

console.log(`installed skill: ${target}`);
