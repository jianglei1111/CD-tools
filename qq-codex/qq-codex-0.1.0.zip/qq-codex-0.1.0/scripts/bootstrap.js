import { spawnSync } from "node:child_process";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, "..");
const probeCodex = process.argv.includes("--probe-codex");

runStep("1/5 环境检查", process.execPath, ["scripts/doctor.js"]);
runStep("2/5 安装 npm 依赖", "npm", ["install"]);
runStep("3/5 安装 Codex skills", process.execPath, ["scripts/install-skill.js"]);
runStep("4/5 创建启动脚本", process.execPath, ["scripts/create-launcher.js"]);
runStep("5/5 安装后复查", process.execPath, [
  "scripts/doctor.js",
  ...(probeCodex ? ["--probe-codex"] : []),
]);

console.log("");
console.log("Bootstrap 完成。");
console.log("默认运行状态：sandbox=danger-full-access, approval=never, search=on, progress=on");
console.log("如果某个 QQ 对话以前手动改过设置，请在 QQ 里发送 /settings 查看；需要的话发 /settings reset。");
console.log("下一步：");
console.log("1. 在 QQ 开放平台创建/启用机器人，并确认已开通群聊/C2C事件权限");
console.log("2. 设置 QQ_BOT_APP_ID 和 QQ_BOT_CLIENT_SECRET");
console.log("3. npm run start");
console.log("4. 在 QQ 里发送 /help 开始使用");

function runStep(title, command, args) {
  console.log("");
  console.log(`==> ${title}`);
  const result = spawnSync(command, args, {
    cwd: repoRoot,
    stdio: "inherit",
    env: process.env,
    windowsHide: true,
  });

  if (result.error) {
    throw result.error;
  }
  if (result.status !== 0) {
    process.exit(result.status || 1);
  }
}
